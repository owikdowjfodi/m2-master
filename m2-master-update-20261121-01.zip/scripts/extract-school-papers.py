import json,re,hashlib
from pathlib import Path
root=Path(__import__('sys').argv[1])
files=json.loads((root/'inspection.json').read_text())
for f in files:
 head=f['firstPage'];year=re.search(r'20(\d\d)\s*[–−-]\s*20(\d\d)',head)
 if year:y=''.join(year.groups())
 else:y=re.match(r'(\d{4})',f['name'])[1]
 grade=re.search(r'S\.?\s*([45])\b',head,re.I)[1]
 test=re.search(r'(?:Chapter\s+)?Test\s*0?(\d+)',head,re.I)
 if test:kind='test'+test[1].zfill(2)
 elif re.search('supplementary examination',head,re.I):kind='supp'
 elif re.search('first term',head,re.I):kind='term1'
 elif re.search('second term',head,re.I):kind='term2'
 else:kind='final'
 f['paperId']=f'school-ttca-{y}-s{grade}-{kind}'
 f['paperTitle']=f'TTCA · 20{y[:2]}–20{y[2:]} · 中{grade} · '+('測驗 '+str(int(test[1])) if test else {'supp':'補考','term1':'上學期考試','term2':'下學期考試','final':'期終考試'}[kind])
 pages=json.loads((root/(f['id']+'.pages.json')).read_text());anchors=[]
 for p in pages:
  for line in p['lines']:
   m=re.match(r'^(\d{1,2})\.(?:\s|$)',line['text'])
   if not m or not 1<=int(m[1])<=80 or line['bbox'][0]>90:continue
   if re.search('write your name|answer all questions|supplementary answer sheets|unless otherwise|diagrams in this paper|only calculators',line['text'],re.I):continue
   anchors.append({'number':int(m[1]),'page':p['page'],'top':max(0,line['bbox'][1]-14),'x':line['bbox'][0],'line':line['text']})
 # Preserve strictly ordered top-level questions, excluding numerical working and instructions.
 good=[];expected=1
 for a in anchors:
  if a['number']==expected:good.append(a);expected+=1
 f['anchors']=good;f['anchorCandidates']=anchors
 qs=[]
 for i,a in enumerate(good):
  end=good[i+1] if i+1<len(good) else {'page':len(pages),'top':pages[-1]['height']-25}
  assets=[];texts=[]
  for pn in range(a['page'],end['page']+1):
   p=pages[pn-1];top=a['top'] if pn==a['page'] else 30;bottom=end['top']-2 if pn==end['page'] and i+1<len(good) else p['height']-25
   if bottom<=top:continue
   lines=[l for l in p['lines'] if l['bbox'][3]>top and l['bbox'][1]<bottom and l['bbox'][0]>28]
   text='\n'.join(l['text'] for l in lines if 'Answers written in the margins' not in l['text'])
   # Ignore blank answer-only continuation pages, retain any substantive content.
   useful=re.sub(r'[\s~\d_]+','',text)
   if not useful:continue
   # Content bounds include diagrams through conservative page crop; trim empty space only later with visual evidence.
   assets.append({'page':pn,'width':p['width'],'height':p['height'],'top':round(top,2),'bottom':round(bottom,2)})
   texts.append(text)
  qs.append({'number':a['number'],'assets':assets,'text':'\n'.join(texts)})
 f['questions']=qs
(root/'extracted.json').write_text(json.dumps(files,ensure_ascii=False,indent=2))
groups={}
for f in files:groups.setdefault(f['paperId'],[]).append(f)
manifest=[]
for sid,fs in groups.items():
 question=next((f for f in fs if not f['solution']),None);solution=next((f for f in fs if f['solution']),None);primary=question or solution
 manifest.append({'id':sid,'title':primary['paperTitle'],'questionFileId':question['id'] if question else None,'solutionFileId':solution['id'] if solution else None,'primaryFileId':primary['id'],'allFileIds':[f['id'] for f in fs],'questions':primary['questions'],'sourceIncludesAnswers':question is None})
(root/'paper-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
for f in files:print(f['paperId'],'SOL' if f['solution'] else 'Q',len(f['questions']),'seq',','.join(str(a['number']) for a in f['anchorCandidates'])[:170])
print('GROUPS',len(groups),'QUESTIONS',sum(len(g['questions']) for g in manifest),'SOLUTIONONLY',sum(g['sourceIncludesAnswers'] for g in manifest))
