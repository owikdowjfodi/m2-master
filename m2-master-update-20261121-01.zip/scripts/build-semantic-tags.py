"""Attach mathematical context tags. Source reviews override content-text suggestions."""
import json,re
from pathlib import Path
root=Path(__file__).resolve().parents[1]
bank=json.loads((root/'content/imported-bank.json').read_text())
labels={'differentiation':'微分 Differentiation','integration':'積分 Integration','limits':'極限 Limits','binomial':'二項式 Binomial','induction':'歸納法 Induction','surds':'根式 Surds','functions':'函數 Functions','distance':'距離 Distance','area':'面積 Area','volume':'體積 Volume','trigonometry':'三角 Trigonometry','geometry':'幾何 Geometry','angle':'角度 Angle','optimization':'最值 Optimization','rates':'變率 Rates','motion':'運動 Motion','proof':'證明 Proof','parameters':'參數 Parameters','domain':'定義域 Domain','equations':'方程 Equations','graphs':'圖像 Graphs','symmetry':'對稱 Symmetry','sequences':'數列與求和 Sequences','exp-log':'指數與對數 Exp / Log','algebra':'代數 Algebra','vectors':'向量 Vectors','matrices':'矩陣與行列式 Matrices','probability':'概率 Probability'}
rules={
'differentiation':r'differenti|derivative|微分|導數',
'integration':r'integral|integrat|積分',
'limits':r'\blim\b|\blimit\b|極限',
'binomial':r'binomial|二項',
'induction':r'induction|歸納',
'surds':r'rationaliz|rationalis|根式|有理化',
'functions':r'\bfunction\b|函數',
'distance':r'\bdistance\b|\bshortest\b|距離|最短距離',
'area':r'\barea\b|面積',
'volume':r'\bvolume\b|\bcapacity\b|體積|容積|旋轉體',
'trigonometry':r'\b(?:sin|cos|tan|sec|csc|cot|sine|cosine|tangent)\b|三角|弧度|radian',
'geometry':r'\b(?:triangle|circle|rectangle|parallelogram|sphere|cone|cylinder|plane|tetrahedron)\b|幾何|三角形|圓形|圓錐|球體|平面距離',
'angle':r'\bangle\b|radian|角度|夾角|弧度',
'optimization':r'\b(?:maximum|minimum|maximize|minimize|greatest|least)\b|最值|極值|最大|最小',
'rates':r'\brate\b|變率|水深',
'motion':r'\b(?:velocity|acceleration|particle|displacement|speed)\b|運動|速度|加速度|位移',
'proof':r'\b(?:prove|proof|show that|induction)\b|證明|歸納',
'parameters':r'\bparameter\b|參數|未知常數',
'domain':r'\bdomain\b|extraneous|定義域|增根',
'equations':r'\b(?:equation|solve)\b|方程|解的分類',
'graphs':r'\b(?:graph|sketch|asymptote|inflexion|inflection)\b|圖像|描繪|漸近線|拐點',
'symmetry':r'\b(?:symmetr|odd function|even function)|對稱|奇偶',
'sequences':r'\b(?:sum|summation|sequence|series|induction)\b|數列|求和|歸納|通項|二項',
'exp-log':r'\b(?:ln|log|exponential|logarithm)\b|指數|對數',
'algebra':r'\b(?:factoriz|factoris|expand|coefficient|binomial|polynomial|rationalize|rationalise)|代數|根式|展開|係數|二項|有理化',
'vectors':r'\bvector\b|向量|數量積|純量積|投影',
'matrices':r'\b(?:matri|determinant)|矩陣|行列式|消元|克拉默',
'probability':r'\bprobability\b|概率|機率'}
manual={}
p=root/'content/school-reviewed.json'
if p.exists():manual=json.loads(p.read_text())
ratings={}
for q in bank['questions']:
 text=' '.join([q.get('type',''),' '.join(q.get('topics',[])),q.get('reviewApproach',''),q.get('searchText','')])
 tags=[];evidence={}
 for key,pattern in rules.items():
  m=re.search(pattern,text,re.I)
  if m:tags.append(key);evidence[key]='按題型或可辨認文字「'+m.group(0)+'」初標，需按原題核對。'
 # Chapter is evidence for broad mathematical content, not application context.
 broad={0:'surds',1:'induction',2:'binomial',3:'functions',4:'trigonometry',5:'limits',6:'differentiation',7:'differentiation',8:'integration',9:'integration',10:'integration',11:'integration',12:'matrices',13:'matrices',14:'vectors',15:'vectors'}.get(q['chapter'])
 if broad and broad not in tags:tags.append(broad);evidence[broad]='按已編排章節初標。'
 if q['chapter']==1 and 'proof' not in tags:tags.append('proof');evidence['proof']='數學歸納法證明題。'
 if q['id'] in manual:
  record=manual[q['id']];tags=list(record['semanticTags']);evidence={k:record['reason'] for k in tags};status='source-reviewed'
  if broad and broad not in tags:tags.append(broad);evidence[broad]='按逐題整理的主要知識點章節分類。'
 else:status='provisional'
 ratings[q['id']]={'tags':tags,'reasons':evidence,'status':status}
# Original questions have readable prompts and existing worked answers.
original=json.loads((root/'content/original-tag-input.json').read_text())
for q in original:
 text=' '.join([q['title'],q['prompt'],q.get('solution',''),q.get('explanation','')]);tags=[k for k,p in rules.items() if re.search(p,text,re.I)]
 ratings[q['id']]={'tags':tags,'reasons':{k:'按本站題目及現有解答辨認內容。' for k in tags},'status':'source-reviewed'}
assert set(ratings)=={q['id'] for q in bank['questions']}|{q['id'] for q in original}
(root/'content/semantic-tags.json').write_text(json.dumps({'labels':labels,'questions':ratings},ensure_ascii=False,indent=2)+'\n')
print('Semantic tag coverage',len(ratings))
