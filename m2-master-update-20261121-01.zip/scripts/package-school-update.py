"""Split a valid full update archive into independently extractable GitHub web upload parts."""
from pathlib import Path
import zipfile,sys
source=Path(sys.argv[1]);dest=Path(sys.argv[2]);dest.mkdir(parents=True,exist_ok=True);limit=19*1024*1024
with zipfile.ZipFile(source) as src:
 metadata=[];batches=[];current=[];size=0
 for info in src.infolist():
  if info.filename.startswith(('docs/source-pages/school-','docs/school-papers/')):
   if current and size+info.compress_size>limit:batches.append(current);current=[];size=0
   current.append(info.filename);size+=info.compress_size
  else:metadata.append(info.filename)
 if current:batches.append(current)
 for index,names in enumerate([metadata]+batches,1):
  output=dest/f'm2-master-update-20261121-{index:02}.zip'
  with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as out:
   for name in names:out.writestr(name,src.read(name))
  assert output.stat().st_size<25*1024*1024
  print(output.name,output.stat().st_size)
