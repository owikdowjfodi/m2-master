import json,re,fitz,shutil
from pathlib import Path
from PIL import Image
root=Path(__import__('sys').argv[1])
site=Path(__file__).resolve().parents[1]
papers=json.loads((root/'paper-manifest.json').read_text());files=json.loads((root/'extracted.json').read_text());byid={f['id']:f for f in files}
(site/'docs/school-papers').mkdir(exist_ok=True)
rendered=set()
def assets_for(fileid,assets,kind,sid):
 doc=fitz.open(root/(fileid+'.pdf'));out=[]
 for a in assets:
  page=doc[a['page']-1];src=f'source-pages/{sid}-{kind}-p{a["page"]:02}.webp'
  if src not in rendered:
   pix=page.get_pixmap(matrix=fitz.Matrix(1250/page.rect.width,1250/page.rect.width),alpha=False)
   Image.frombytes('RGB',[pix.width,pix.height],pix.samples).save(site/'docs'/src,'WEBP',quality=85,method=4);rendered.add(src)
  out.append({**a,'src':src})
 return out
for paper in papers:
 sid=paper['id'];primary=byid[paper['primaryFileId']];sol=byid.get(paper['solutionFileId']);paper['sourcePdf']=f'school-papers/{sid}-'+('combined' if paper['sourceIncludesAnswers'] else 'questions')+'.pdf'
 shutil.copyfile(root/(primary['id']+'.pdf'),site/'docs'/paper['sourcePdf'])
 if sol:
  paper['solutionPdf']=paper['sourcePdf'] if sol['id']==primary['id'] else f'school-papers/{sid}-solutions.pdf'
  if sol['id']!=primary['id']:shutil.copyfile(root/(sol['id']+'.pdf'),site/'docs'/paper['solutionPdf'])
 primary_pages=json.loads((root/(primary['id']+'.pages.json')).read_text())
 for q in paper['questions']:
  raw=q['assets'];answer_in_source=False
  if paper['sourceIncludesAnswers']:
   # A duplicated question number identifies the original answer column.
   page=primary_pages[raw[0]['page']-1]
   duplicate=next((l for l in page['lines'] if re.fullmatch(str(q['number'])+r'\.',l['text']) and l['bbox'][0]>300 and raw[0]['top']<=l['bbox'][1]<raw[0]['bottom']),None)
   if duplicate:
    raw=[{**a,'right':round(duplicate['bbox'][0]-7,2),'left':30} for a in raw]
   else:
    endings=[]
    for a in raw:
     p=primary_pages[a['page']-1]
     endings += [(a['page'],l['bbox'][3]+5) for l in p['lines'] if a['top']<=l['bbox'][1]<a['bottom'] and re.search(r'\(\d+\s*marks?\)',l['text'],re.I)]
    if endings:
     endpage,endbottom=endings[-1];raw=[{**a,'bottom':min(a['bottom'],endbottom)} if a['page']==endpage else a for a in raw if a['page']<=endpage]
    else:answer_in_source=True
  q['answerInSource']=answer_in_source
  q['assets']=assets_for(primary['id'],raw,'q',sid)
  if sol:
   matched=next((r for r in sol['questions'] if r['number']==q['number']),None)
   if matched:q['solutionAssets']=assets_for(sol['id'],matched['assets'],'s',sid)
  q['sourceText']=q.pop('text')
 print(sid,len(paper['questions']),flush=True)
(root/'prepared-papers.json').write_text(json.dumps(papers,ensure_ascii=False,indent=2))
print('Rendered pages',len(rendered))
