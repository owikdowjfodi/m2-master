const SEMANTIC_LABELS=SEMANTIC_DATA.labels;
for(const ch of CHAPTERS)for(const q of ch.questions){const r=SEMANTIC_DATA.questions[q.id];if(!r)throw new Error('Missing semantic tags '+q.id);q.semanticTags=r.tags;q.semanticTagReasons=r.reasons;q.semanticTagStatus=r.status;}
