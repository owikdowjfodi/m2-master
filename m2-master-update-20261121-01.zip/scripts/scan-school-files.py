import json,fitz,hashlib,re
from pathlib import Path
root=Path(__import__('sys').argv[1])
files=json.loads((root/'drive-manifest.json').read_text())
seen={};out=[]
for f in files:
 p=root/(f['id']+'.pdf');f['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
 if f['sha256'] in seen:f['duplicateOf']=seen[f['sha256']]
 else:seen[f['sha256']]=f['id']
 doc=fitz.open(p);f['pages']=len(doc);f['solution']=bool(re.search(r'marking|solution|_sol_',f['name'],re.I));f['textChars']=sum(len(p.get_text().strip()) for p in doc)
 pages=[]
 for i,page in enumerate(doc):
  blocks=page.get_text('dict')['blocks'];lines=[]
  for b in blocks:
   for l in b.get('lines',[]):
    text=''.join(s['text'] for s in l['spans']).strip()
    if text:lines.append({'text':text,'bbox':list(l['bbox'])})
  pages.append({'page':i+1,'width':page.rect.width,'height':page.rect.height,'text':page.get_text(),'lines':lines})
 (root/(f['id']+'.pages.json')).write_text(json.dumps(pages,ensure_ascii=False,indent=2))
 f['firstPage']=doc[0].get_text()[:800]
 out.append(f)
(root/'inspection.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
for i,f in enumerate(out):print(i,'SOL' if f['solution'] else ' Q ',f['pages'],f['textChars'],'DUP' if f.get('duplicateOf') else '',f['name'],repr(f['firstPage'][:100]))
