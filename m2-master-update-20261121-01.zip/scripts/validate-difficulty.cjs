const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');const root=path.resolve(__dirname,'..');const output=fs.existsSync(path.join(root,'docs'))?'docs':'docs';const c={URLSearchParams,readStore:()=>({}),document:{addEventListener(){}},location:{hash:''},problem:()=>'',home:()=>'',chaptersPage:()=>'',icon:()=>'',esc:String,math:String,completed:()=>new Set(),bookmarkButton:()=>'',empty:()=>'',progress:()=>0};vm.createContext(c);for(const f of ['data.js','lessons.js','notes-manifest.js','imported-bank.js','content-adapter.js','semantic-tags.js','difficulties.js','study.js','revision.js'])vm.runInContext(fs.readFileSync(path.join(root,output,f),'utf8'),c);vm.runInContext('this.data={chapters:CHAPTERS,lessons:LESSONS,sources:NOTES_MANIFEST.sources}',c);const {chapters,lessons,sources}=c.data;const qs=chapters.flatMap(x=>x.questions);const schoolAudit=JSON.parse(fs.readFileSync(path.join(root,'content/school-import-audit.json')));assert.equal(qs.length,schoolAudit.totalQuestionCount);assert.equal(new Set(qs.map(q=>q.id)).size,schoolAudit.totalQuestionCount);for(const q of qs){assert(Number.isInteger(q.difficultyLevel)&&q.difficultyLevel>=1&&q.difficultyLevel<=3,q.id);assert(q.difficultyReason,q.id);}for(const ch of chapters){for(let l=1;l<=3;l++){c.location.hash=`#chapter/${ch.id}/all?levels=${l}`;const html=c.questionResults(ch,'all');const expected=ch.questions.filter(q=>q.difficultyLevel===l);const ids=[...html.matchAll(/href="#question\/([^"]+)"/g)].map(x=>x[1]);assert.deepEqual(ids,expected.slice(0,12).map(q=>q.id));}for(const p of lessons[ch.id]){const html=c.revisionPanel(ch,p,0,new URLSearchParams());assert(html.includes('Key idea'));for(const m of html.matchAll(/src="(note-pages\/[^"]+)"/g))assert(fs.existsSync(path.join(root,output,m[1])),m[1]);}}
for(let i=0;i<sources.length;i++)for(let p=1;p<=sources[i].pages;p++)assert(fs.existsSync(path.join(root,output,`note-pages/note-${String(i+1).padStart(2,'0')}-${String(p).padStart(3,'0')}.webp`)));
c.location.hash='#chapter/9/all?levels=2,3&family=sin-cos&method=substitution&sort=easy';const html=c.questionResults(chapters[9],'all');const ids=[...html.matchAll(/href="#question\/([^"]+)"/g)].map(x=>x[1]);assert(ids.length>0);for(const id of ids){const q=qs.find(q=>q.id===id);assert([2,3].includes(q.difficultyLevel)&&q.functionFamilies.includes('sin-cos')&&q.methodTags.includes('substitution'));}console.log('Verified all question levels and stable IDs; 48 difficulty filter cases; combined method/function filter; 106 revision panels; all 479 original images.');

// Exhaust the 3^4 rubric possibilities, including the single-3 escalation.
for(let A=1;A<=3;A++)for(let B=1;B<=3;B++)for(let C=1;C<=3;C++)for(let D=1;D<=3;D++){
 const scores={A,B,C,D},sum=A+B+C+D,expected=sum>=10?3:sum>=7||Math.max(A,B,C,D)===3?2:1;
 assert.equal(c.rubricLevel(scores),expected,JSON.stringify(scores));
}
for(const q of qs){
 const r=q.rubric;assert(r&&r.reasons&&r.evidence,q.id);assert.equal(r.total,Object.values(r.scores).reduce((a,b)=>a+b,0));assert.equal(q.difficultyLevel,c.rubricLevel(r.scores));
 assert.deepEqual(Array.from(r.estimatedMinutes),({1:[1,2],2:[3,5],3:[6,10]})[q.difficultyLevel]);
 for(const k of 'ABCD')assert(r.reasons[k]?.trim().length>=4,q.id+k);
 assert(r.roles.length>0&&r.roles.every(role=>['example','variation','trap','capstone'].includes(role)));
 assert(c.rubricPanel(q).includes(r.total+'/12'));assert(!c.rubricPanel(q).includes('★'));
 for(const p of q.subparts||[]){assert(p.rubric,q.id+' '+p.part);assert.equal(p.difficultyLevel,c.rubricLevel(p.rubric.scores));}
}
for(const ch of chapters)for(const role of ['example','variation','trap','capstone']){
 c.location.hash=`#chapter/${ch.id}/all?role=${role}`;
 const html=c.questionResults(ch,'all'),actual=[...html.matchAll(/href="#question\/([^"]+)"/g)].map(m=>m[1]);
 assert.deepEqual(actual,ch.questions.filter(q=>q.roles.includes(role)).slice(0,12).map(q=>q.id));
}
// Filters must preserve active role, difficulty, topic and method, resetting pagination.
const elements={'question-search-form':{dataset:{chapter:'9',section:'all'},elements:{q:{value:''}}},'question-source':{value:'ppp'},'question-kind':{value:'long'},'question-role':{value:'capstone'},'question-method':{value:'substitution'},'question-sort':{value:'hard'},'question-topic':{value:'test'}};
c.document.getElementById=id=>elements[id];c.location.hash='#chapter/9/all?levels=2,3&family=sin-cos&page=3';c.updateQuestionFilter();
const params=new URLSearchParams(c.location.hash.split('?')[1]);assert.equal(params.get('levels'),'2,3');assert.equal(params.get('role'),'capstone');assert.equal(params.get('source'),'ppp');assert.equal(params.get('family'),'sin-cos');assert.equal(params.get('method'),'substitution');assert.equal(params.get('topic'),'test');assert(!params.has('page'));
console.log('Verified 81 rubric combinations, A–D evidence/time metadata, subpart coverage, 64 role filter cases and filter-state preservation.');
