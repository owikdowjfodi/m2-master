"""Import school papers using reviewed per-question classifications and retained original files."""
import json,re,sys,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[1];inputs=Path(sys.argv[1]);papers=json.loads((inputs/'prepared-papers.json').read_text());files=json.loads((inputs/'inspection.json').read_text());byid={f['id']:f for f in files};review=json.loads((R/'content/school-reviewed.json').read_text());bank=json.loads((R/'content/imported-bank.json').read_text())
previous_ids=[q['id'] for q in bank['questions'] if not q.get('schoolPaperId')]
new=[]
for p in papers:
 sid=p['id'];source=byid[p['primaryFileId']];qids=[]
 for raw in p['questions']:
  id='src-'+sid+'-q'+str(raw['number']).zfill(2);r=review[id];qids.append(id)
  text=raw['sourceText'];marks=[int(m) for m in re.findall(r'\((\d+)\s*marks?\)',text,re.I)]
  q={'id':id,'chapter':r['chapter'],'type':r['type'],'title':p['title']+' · Q'+str(raw['number']).zfill(2)+' · '+r['type'],'prompt':f'請作答原卷第 {raw["number"]} 題，保留全部小題及原有圖像。','kind':'long','marks':sum(marks) or None,'sourceId':sid,'schoolPaperId':sid,'sourceTitle':p['title'],'sourceQuestion':raw['number'],'sourcePage':raw['assets'][0]['page'],'sourceKind':'exam','assets':raw['assets'],'topics':r['topics'],'tags':['School pp','TTCA'],'semanticTags':r['semanticTags'],'semanticTagReason':r['reason'],'searchText':text,'difficultyLevel':1,'difficulty':'L1 · 基礎（待核對）','difficultyReason':'按可用題目文字初評，完整解答待核對。','difficultyStatus':'estimated','extension':False,'sourcePdf':p['sourcePdf'],'sourceIncludesAnswers':p['sourceIncludesAnswers'],'answerInSource':raw['answerInSource']}
  if p.get('solutionPdf'):q['solutionPdf']=p['solutionPdf']
  if raw.get('solutionAssets'):
   q['solutionAssets']=raw['solutionAssets'];q['solutionNote']='以下按同一份學校試卷及題號配對其附帶解答／評分參考；保留原卷標記，並非 HKEAA 官方評分準則，亦未聲稱逐步數學驗證全部答案。'
  if p['sourceIncludesAnswers']:
   q['sourceNote']='此份只找到附題解答卷；題幹已按版面擷取。完整原頁及 PDF 含答案，請完成練習後再開啟。'
   if raw['answerInSource']:q['sourceNote']='此份只有附題解答卷，未能可靠分離此題題幹與答案；原圖預設收起，展開會看到答案。'
  # Retain function-family and standard method filters for every imported question.
  families=[]
  for key,pattern in [('sin-cos',r'\b(?:sin|cos)\b|正弦|餘弦'),('tan-sec',r'\b(?:tan|sec)\b|正切|正割'),('cot-csc',r'\b(?:cot|csc|cosec)\b|餘切|餘割'),('exp-log',r'\b(?:ln|log|exponential)\b|指數|對數'),('inverse-trig',r'arctan|arcsin|反三角')]:
   if re.search(pattern,text+' '+r['type']+' '.join(r['topics']),re.I):families.append(key)
  if len([x for x in families if x in ['sin-cos','tan-sec','cot-csc']])>1:families.append('mixed-trig')
  q['functionFamilies']=families or ['unclassified'];q['methodTags']=[]
  for key,pattern in [('parts',r'by parts|分部積分'),('substitution',r'substitut|代換'),('symmetry',r'對稱|奇偶|symmetry')]:
   if re.search(pattern,text+' '+r['type']+' '.join(r['topics']),re.I):q['methodTags'].append(key)
  new.append(q)
 src={'id':sid,'title':p['title'],'filename':source['name'],'pages':source['pages'],'sha256':source['sha256'],'kind':'exam','school':'Tsung Tsin Christian Academy','schoolCollection':True,'count':len(p['questions']),'sourcePdf':p['sourcePdf'],'sourceIncludesAnswers':p['sourceIncludesAnswers'],'inputFileIds':p['allFileIds']}
 if p.get('solutionPdf'):src['solutionPdf']=p['solutionPdf']
 bank['sources']=[s for s in bank['sources'] if s['id']!=sid]+[src]
bank['questions']=[q for q in bank['questions'] if not q.get('schoolPaperId')]+new
assert len(new)==560 and len({q['id'] for q in new})==560
assert set(review)=={q['id'] for q in new}
for s in bank['sources']:s['count']=sum(q['sourceId']==s['id'] or s['id'] in q.get('linkedSourceIds',[]) for q in bank['questions'])
(R/'content/imported-bank.json').write_text(json.dumps(bank,ensure_ascii=False,separators=(',',':'))+'\n')
audit={'inputFolder':'M2/School pp','inputFileCount':len(files),'paperCount':len(papers),'newQuestionCount':len(new),'previousImportedIds':previous_ids,'newIds':[q['id'] for q in new],'totalQuestionCount':len(bank['questions'])+45,'sourceOnlyAnswerPapers':[p['id'] for p in papers if p['sourceIncludesAnswers']],'unseparatedQuestionIds':[q['id'] for q in new if q['answerInSource']],'solutionMatched':sum(bool(q.get('solutionAssets')) for q in new),'papers':[{'id':p['id'],'title':p['title'],'questionCount':len(p['questions']),'questionFileId':p['questionFileId'],'solutionFileId':p['solutionFileId'],'allFileIds':p['allFileIds'],'sourcePdf':p['sourcePdf'],'solutionPdf':p.get('solutionPdf')} for p in papers],'files':[{k:f[k] for k in ['id','name','sha256','pages','solution']} for f in files],'limitations':['學校題目長短題均保留原卷，未實作沒有可靠選項及答案資料的自動MC評分。','難度仍為A–D文字初評，未完成逐題完整解答驗證。','相同試卷的副本與配套解答按同一題號配對，保留所有輸入檔案的出處紀錄。']}
(R/'content/school-import-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
print('Imported',len(new),'school questions. Total',len(bank['questions'])+45,'solution matches',audit['solutionMatched'],'inseparable',len(audit['unseparatedQuestionIds']))
