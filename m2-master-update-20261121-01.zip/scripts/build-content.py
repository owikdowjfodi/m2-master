import re,json
from pathlib import Path
root=Path(__file__).resolve().parents[1];lessons={};ch=None;page=None
for line in (root/'content/lessons.md').read_text().splitlines():
 if re.fullmatch(r'# \d+',line):ch=int(line[2:]);lessons[str(ch)]=[];page=None
 elif line.startswith('## '):page={'title':line[3:],'body':''};lessons[str(ch)].append(page)
 elif line.startswith('@source ') and page is not None:page['source']=line[8:]
 elif page is not None:page['body']+=line+'\n'
assert set(lessons)==set(map(str,range(16)))
extra=json.loads((root/'content/detailed-lessons.json').read_text())
for ch,pages in extra.items():lessons[ch].extend(pages)
for pages in lessons.values():
 for p in pages:p['body']=p['body'].strip()
(root/'docs/lessons.js').write_text('const LESSONS = '+json.dumps(lessons,ensure_ascii=False,separators=(',',':'))+';\n')
bank=json.loads((root/'content/imported-bank.json').read_text())
for q in bank['questions']:
 q['searchText']=q.get('searchText','')[:1200] if q.get('pppYear') or q.get('schoolPaperId') else ' '.join(re.findall(r'[A-Za-z]{3,}',q.get('searchText','')))[:220]
(root/'docs/imported-bank.js').write_text('const IMPORTED_BANK = '+json.dumps(bank,ensure_ascii=False,separators=(',',':'))+';\n')
# Generated JSON duplicate is unnecessary for the browser; keep the JS as the canonical generated bundle.

print('Lessons:',sum(map(len,lessons.values())),'pages; imported:',len(bank['questions']))

manifest=json.loads((root/'content/notes-manifest.json').read_text())
(root/'docs/notes-manifest.js').write_text('const NOTES_MANIFEST = '+json.dumps(manifest,ensure_ascii=False,separators=(',',':'))+';\n')

rubrics=json.loads((root/'content/difficulty-rubrics.json').read_text())
runtime=(root/'scripts/rubric-runtime.js').read_text()
(root/'docs/difficulties.js').write_text('const DIFFICULTY_RUBRICS='+json.dumps(rubrics,ensure_ascii=False,separators=(',',':'))+';\n'+runtime)

semantic=json.loads((root/'content/semantic-tags.json').read_text())
(root/'docs/semantic-tags.js').write_text('const SEMANTIC_DATA='+json.dumps(semantic,ensure_ascii=False,separators=(',',':'))+';\n'+(root/'scripts/semantic-runtime.js').read_text())
