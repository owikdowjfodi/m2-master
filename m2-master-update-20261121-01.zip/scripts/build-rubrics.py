"""Evidence-based provisional scoring. Never read legacy star levels.
Editorial overrides live separately so rebuilding cannot erase reviewed scores.
"""
import json,re
from pathlib import Path
root=Path(__file__).resolve().parents[1]
bank=json.loads((root/'content/imported-bank.json').read_text())
labels={1:'基礎',2:'進階',3:'挑戰'}
def tier(s):
 total=sum(s.values())
 return 3 if total>=10 else 2 if total>=7 or 3 in s.values() else 1

def provisional(q):
 # Only content evidence: no marks, question number, source ranking or old difficulty.
 topics=q.get('topics') or [q.get('type','')]
 text=' '.join([q.get('title',''),q.get('type',''),' '.join(topics),q.get('searchText','')])
 scores=dict(A=1,B=1,C=1,D=1)
 reasons={
 'A':'可用分類為「'+ '、'.join(topics[:4])+'」；暫按單一概念計，未能由文字確認所有知識點。',
 'B':'可用文字未能確認特殊解題路徑；暫按直接方法計，需對照原圖及解答。',
 'C':'未有完整解答可核實運算量；暫記 1 分，不代表已確認可在三步內完成。',
 'D':'可用文字未確認特殊限制；暫記 1 分，不代表原題沒有陷阱。'}
 if len(topics)>=2 or re.search(r'與|、|綜合|初始條件|相關變率|旋轉體',q.get('type','')):
  scores['A']=2;reasons['A']='已標記多個題目主題：'+'、'.join(topics[:4])+'；跨單元整合程度待核對。'
 patterns={
 'B':[(3,r'分類討論|逆向|構造|自行建立|case.by.case|deduce.*hence'),(2,r'因式分解|有理化|配方|分部積分|代換|隱函數|消元|恆等式|曲線交點|曲線描繪|解的分類|最值|第一原理|幾何證明|三角方程|substitut|by parts|factoriz|implicit|eliminat')],
 'C':[(3,r'多個參數|參數討論|抽象參數|高次展開|繁複運算'),(2,r'展開|聯立|消元|分部積分|求逆|[xyz]\b|expand|simultaneous|inverse matrix|by parts')],
 'D':[(3,r'增根|隱蔽.*定義域|extraneous|hidden domain'),(2,r'正負號|弧度|單位|定義域|domain|radian|units?\b')]
 }
 for k,rules in patterns.items():
  for score,pattern in rules:
   m=re.search(pattern,text,re.I)
   if m:
    scores[k]=score;reasons[k]=f'可用題目文字出現「{m.group(0)}」，據此暫評 {score} 分；尚待原圖及完整解答核對。';break
 return {'scores':scores,'reasons':reasons,'status':'provisional','evidence':'分類及抽取文字；未逐題完成解答核對。','roles':['variation'],'roleStatus':'provisional','roleReason':'暫作變式訓練編排；未確認與哪一例題配對。','subparts':[]}

ratings={q['id']:provisional(q) for q in bank['questions']}
for name in ['original-rubrics.json','ppp-rubrics.json','school-rubrics.json']:
 p=root/'content'/name
 if p.exists():ratings.update(json.loads(p.read_text()))
for id,r in ratings.items():
 r.setdefault('evidence','逐題解題策略摘要重新評分；未完成逐題完整解答驗證。' if r['status']=='strategy-reviewed' else '按可用題目文字初評；待核對。')
 s=r['scores'];assert set(s)==set('ABCD') and all(type(v)==int and 1<=v<=3 for v in s.values()),id
 r['total']=sum(s.values());r['level']=tier(s);r['estimatedMinutes']={1:[1,2],2:[3,5],3:[6,10]}[r['level']]
 if r['status']=='strategy-reviewed':
  q=next(q for q in bank['questions'] if q['id']==id)
  roles=[]
  if s['D']==3:roles.append('trap')
  if r['level']==3 and q.get('relatedChapters'):roles.append('capstone')
  r.setdefault('roles',roles or ['variation']);r.setdefault('roleStatus','strategy-reviewed' if roles else 'provisional')
  r.setdefault('roleReason','按已記錄的限制或跨課題策略選作專項練習；未附完整逐步解答。' if roles else '暫作變式訓練編排，例題配對待確認。')
 r.setdefault('roles',['variation']);r.setdefault('roleStatus','provisional');r.setdefault('roleReason','暫作變式訓練編排，例題配對待確認。')
 for p in r.get('subparts',[]):
  p['total']=sum(p['scores'].values());p['level']=tier(p['scores'])
assert len(ratings)==len(bank['questions'])+len(json.loads((root/'content/original-rubrics.json').read_text())),len(ratings)
(root/'content/difficulty-rubrics.json').write_text(json.dumps({'schemaVersion':1,'policy':'4–6 基礎（任何維度3分升進階）；7–9進階；10–12挑戰。4:4:2只用於選題，並非配額。','questions':ratings},ensure_ascii=False,indent=2)+'\n')
from collections import Counter
print('Rubric coverage',len(ratings),'tiers',dict(Counter(r['level'] for r in ratings.values())),'status',dict(Counter(r['status'] for r in ratings.values())))
