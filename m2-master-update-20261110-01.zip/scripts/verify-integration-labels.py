"""Use question-number-aligned OCR crops to prevent neighbouring questions contaminating function labels."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,csv,io,re,subprocess,os
from PIL import Image
root=Path(__file__).resolve().parents[1];bank_path=root/'content/imported-bank.json';bank=json.loads(bank_path.read_text());cache=Path('/workspace/scratch/f98ed2dea446/integration-ocr');cache.mkdir(exist_ok=True)
qs=[q for q in bank['questions'] if q['chapter'] in [8,9,10] and q.get('sourceKind')=='textbook'];srcs=sorted({a['src'] for q in qs for a in q['assets']})
def ocr(src):
 target=cache/(Path(src).stem+'.json')
 if target.exists():return src,json.loads(target.read_text())
 env=dict(os.environ,OMP_THREAD_LIMIT='1')
 raw=subprocess.run(['tesseract',str(root/'dist'/src),'stdout','-l','eng','--psm','3','tsv'],capture_output=True,text=True,check=True,env=env).stdout
 words=[]
 for d in csv.DictReader(io.StringIO(raw),delimiter='\t'):
  if d['text'].strip():words.append({k:d[k] for k in ['left','top','width','height','text']})
 target.write_text(json.dumps(words));return src,words
with ThreadPoolExecutor(max_workers=4) as pool:pages=dict(pool.map(ocr,srcs))
fixed=0;evidence=[]
for q in qs:
 a=q['assets'][0];src=a['src'];im=Image.open(root/'dist'/src);w,h=im.size;words=pages[src];num=str(q['sourceQuestion'])
 anchors=[]
 for d in words:
  m=re.fullmatch(r'(\d{1,3})[.,)]',d['text'])
  if m and float(d['left'])<w*.20:
   anchors.append((int(m[1]),float(d['top'])/h*a['height'],float(d['left'])/w*a['width']))
 candidates=[z for z in anchors if str(z[0])==num and a['top']-35<z[1]<a['bottom']+20]
 if candidates:
  chosen=min(candidates,key=lambda z:abs(z[1]-(a['top']+12)))
  top=max(0,chosen[1]-8)
  nexts=[z for z in anchors if z[0]==int(num)+1 and z[1]>chosen[1] and abs(z[2]-chosen[2])<12]
  bottom=min(nexts,key=lambda z:z[1])[1]-8 if nexts else a['bottom']
  if bottom>top+10:
   q.setdefault('originalAssets',json.loads(json.dumps(q['assets'])))
   a['top']=round(top,2)
   if len(q['assets'])==1:a['bottom']=round(bottom,2)
   fixed+=1
 text=[]
 for part in q['assets']:
  iw,ih=Image.open(root/'dist'/part['src']).size
  selected=[d for d in pages[part['src']] if float(d['top'])+float(d['height'])/2>=part['top']/part['height']*ih and float(d['top'])+float(d['height'])/2<=part['bottom']/part['height']*ih]
  text.append(' '.join(d['text'] for d in sorted(selected,key=lambda d:(round(float(d['top'])/10),float(d['left'])))))
 cleaned=' '.join(text)
 if cleaned:q['classificationText']=cleaned;q['classificationBasis']='number-aligned source image text'
 evidence.append({'id':q['id'],'questionNumberLocated':bool(candidates),'classificationText':cleaned,'crop':q['assets']})
bank_path.write_text(json.dumps(bank,ensure_ascii=False,separators=(',',':'))+'\n')
(root/'content/integration-classification-audit.json').write_text(json.dumps({'questions':evidence,'alignedQuestionStarts':fixed,'sourcePagesRead':len(srcs)},ensure_ascii=False,indent=2)+'\n')
print('OCR pages',len(srcs),'question crops aligned',fixed,'/',len(qs),flush=True)
