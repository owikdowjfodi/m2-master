"""Add multi-label function families without discarding original question types or IDs."""
from pathlib import Path
import json,re,collections
root=Path(__file__).resolve().parents[1];path=root/'content/imported-bank.json';bank=json.loads(path.read_text())
labels={'sin-cos':'sin／cos','tan-sec':'tan／sec','cot-csc':'cot／csc','algebra':'代數函數','exp-log':'指數／對數','inverse-trig':'反三角函數'}
summary=collections.Counter()
for q in bank['questions']:
 text=q.get('classificationText') or (q.get('searchText','')+' '+q.get('prompt',''));text=text.lower()
 families=[]
 native=q.get('searchText','').lower()
 if q.get('sourceKind')=='textbook':
  number=str(q.get('sourceQuestion',''));parts=re.split(r'(?<!\d)'+re.escape(number)+r'\.\s*',native,maxsplit=1)
  if len(parts)==2:native=re.split(r'(?<!\d)'+str(int(number)+1)+r'\.\s*',parts[1],maxsplit=1)[0]
 def has(pattern):return re.search(pattern,text) is not None
 if has(r'(?:sin|cos)(?![a-z])'):families.append('sin-cos')
 if has(r'(?:tan|sec)(?![a-z])'):families.append('tan-sec')
 if has(r'(?:cot|csc|cosec)(?![a-z])'):families.append('cot-csc')
 if has(r'arc(?:sin|cos|tan)|(?:sin|cos|tan)\s*(?:\^\s*\{?-1|[−-]1)'):families.append('inverse-trig')
 if has(r'(?<![a-z])(?:ln|log|exponential|logarithm)(?![a-z])|e\^|e[𝑥x]') or re.search(r'(?<![a-z])(?:e|ln|log)(?![a-z])',native):families.append('exp-log')
 if not families:families=['unclassified']
 q['functionFamilies']=families
 methods=[]
 if has(r'by parts'):methods.append('parts')
 if has(r'substitut|hint[^\n]*let'):methods.append('substitution')
 if has(r'odd function|even function|symmetr'):methods.append('symmetry')
 if has(r'first principle'):methods.append('first-principles')
 if '分部' in q.get('originalType',q['type']) or q.get('sourceId')=='textbook-09' and 127<=int(q['sourceQuestion'])<=143:methods.append('parts')
 q['methodTags']=sorted(set(methods))
 if q['chapter'] in [8,9,10]:
  q.setdefault('originalType',q['type'])
  q['type']=q['originalType']
  trig=[f for f in families if f in ['sin-cos','tan-sec','cot-csc']]
  if trig:
   prefix='曲線還原' if q['originalType']=='初始條件、曲線與運動' else '定積分' if q['chapter']==10 else '三角積分'
   specific=labels[trig[0]] if len(trig)==1 else '多種三角函數混合'
   q['type']=prefix+' · '+specific
   # Keep paper-reference titles readable while exposing precise primary categories.
   if q.get('paperReference'):q['title']=q['type']+' · '+q['paperReference']
   elif q.get('sourceQuestion') is not None:q['title']=q['type']+' · 原題 '+str(q['sourceQuestion'])
   else:q['title']=q['type']
  if q.get('paperReference'):q['title']=q['type']+' · '+q['paperReference']
  elif q.get('sourceQuestion') is not None:q['title']=q['type']+' · 原題 '+str(q['sourceQuestion'])
  for f in families:summary[f]+=1
path.write_text(json.dumps(bank,ensure_ascii=False,separators=(',',':'))+'\n')
(root/'content/topic-classification-report.json').write_text(json.dumps({'integrationQuestionCount':sum(q['chapter'] in [8,9,10] for q in bank['questions']),'families':dict(summary),'method':'Multi-label classification from source question text. Family labels describe functions mentioned in the question, including prescribed substitutions, not necessarily only the integrand. Original type retained. Ambiguous extraction is left unclassified; no parity assumptions are inferred from flattened superscripts.'},ensure_ascii=False,indent=2)+'\n')
print('Integration function families',dict(summary))
