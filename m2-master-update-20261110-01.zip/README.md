# M2 Master

Account-free HKDSE M2 practice website. The final scope has no authentication, teacher/student roles, server uploads or creator dashboard.

## Current content

- 15 pedagogical M2 chapters, plus a separate prerequisite area for surds/rationalisation.
- 77 English pages of expanded Concepts & Formulas notes, with topic contents, derivations, formula conditions, worked examples, common errors, self-check disclosures, previous/next links and device-local reading markers.
- 1,903 imported source questions from the 19 PDFs represented by the user's expanded Word draft: 1,852 textbook/prerequisite questions and 51 school-paper questions.
- The original 30 MC questions and 15 original long questions remain, keeping all their original IDs. Total question count: 1,948.
- Every imported question has a stable ID, chapter, question-type section, source title, PDF page, original question number and at least one original-page image reference.
- Two digital school papers provide 30 source reference solutions, displayed separately from questions. The scanned final paper imports only the clean question set; repeated handwritten attempt pages are excluded.
- Source formulas and diagrams stay as images, since the supplied Word transcription lost mathematical layout. This is not a claim that all imported questions have verified editable LaTeX transcriptions.
- Classification uses original chapter context, content keywords, exercise progression and reviewed school-paper mappings. Integrated questions are assigned to a main concept with related tags where applicable; classification is not a claim that every subpart belongs exclusively to one chapter.
- Original textbook out-of-syllabus markers and identified extension content are flagged. Chapter numbering is pedagogical, not official.

## App behavior

Each chapter fixes Concepts & Formulas first, followed by dynamic question-type sections. The question bank supports 12 items per page, keyword search, source filters (original/textbook/exam/specific paper) and MC/long filtering. Source images load only on opened questions. Full-page viewers preserve access to the entire original page.

MC marking, explanations, retries, local history, bookmarks, chapter progress, activity chart and light/dark theme remain. Long answers support camera/file selection, multiple-image previews, enlargement, notes, browser-local drafts and image downloads.

Limits remain 5 MB/image, 5 images and 20 MB/draft, 50 MB total drafts. No cloud submission, teacher review, AI marking, account registration or cross-device synchronization is claimed. No paid service or external API has been added.

## Files

- `content/lessons.md`: authored expanded notes, source for 77 English lesson pages.
- `content/imported-bank.json`: canonical source question metadata and classification.
- `scripts/build-content.py`: rebuilds browser lesson and bank bundles.
- `scripts/validate-content.cjs`: checks all question IDs, source totals, section mappings, image references, note coverage and 486 LaTeX expressions.
- `dist/data.js`: retained original starter content and IDs.
- `dist/content-adapter.js`: appends imported questions and dynamic type sections.
- `dist/study.js`: expanded note and source-question interface.
- `dist/source-pages/`: original page images needed by the source questions and typed solutions.
- `dist/app.js`, `dist/style.css`, `dist/index.html`: retained app with scoped updates.

KaTeX is bundled locally. Runtime requests go only to this site's static assets. The live Site is public, matching the user's account-free requirement.

## Validation

`node --check` passed for app and study scripts. The content validator passed with 15 M2 chapters, 1 prerequisite area, 19 sources, 1,903 imported questions, 1,948 total questions, 77 English note pages, 1,502 rendered LaTeX expressions and 1,935 valid source-image references.

Browser QA verified expanded note headings, contents and next-page navigation; persistent reading markers; source selection; question bank pagination; original source question display; typed reference-solution modal; and full-page enlargement. Physical Android/iPhone hardware was not available for camera-specific verification; responsive styles and the retained capture input are present.

Source: https://www.edb.gov.hk/attachment/en/curriculum-development/kla/ma/curr/EN_M2_e.pdf


## Source-based English notes update — 9 November 2026

Read all 17 PDFs (479 pages) in Google Drive `M2 / Notes`. The English Concepts & Formulas collection contains 77 pages across the 15 teaching chapters and a supplementary prerequisite area. Source chapter numbering is mapped to the existing website chapter numbering in `content/notes-manifest.json`; every note page has a source section and PDF page range. The manifest includes all filenames and page totals. These are pedagogical chapters, not an official chapter list.

The notes use definitions, conditions, reasoning, derivations, worked examples, error checks and self-check answers. Three original SVG diagrams explain secants/tangents, Riemann rectangles and projections. Supplied-note extensions are labelled, a source concavity wording error is corrected, and the duplicated source section 7.4 is identified by title. Student handwriting and source note scans are not published as note assets.

`content/lessons.md` is the editable source; `python scripts/build-content.py` regenerates note pages and the source manifest. English reading markers use a new versioned key, so old Chinese page positions are not treated as the new pages. Existing MC attempts, question IDs, saved images and bookmarks retain their storage keys. The personal-data clear action removes both note-marker versions.


## bk1.pdf classified past-paper import — 9 November 2026

The 254-page dse.life compilation was absent from the previous 19 source files. Imported 533 question occurrences as 525 distinct original paper references; merged 8 repeated occurrences and retained their alternate source crops in the question interface. Linked 495 printed answer excerpts; 30 questions have no matching printed answer (many are proofs), and no answers were invented. Answer columns are cropped independently and cross-page questions retain continuation pages. The six questions explicitly labelled OUT-OF-SYLLABUS by the PDF are marked as extensions; CE/AL/HL provenance is shown separately from DSE M2.

The bank now contains 2,428 imported questions plus the existing 45 original exercises, for 2,473 total. There are 20 question-source files and the existing 77 English concept pages. `content/bk1-import-audit.json` records the PDF SHA-256, classifications, question and answer pages, and every repeated occurrence. Existing IDs and student storage keys are unchanged.


## Detailed notes and precise function-family classification — 10 November 2026

Expanded the collection to 106 English pages with 29 additional reasoning-led worked lessons. Chapter 9 now has 20 pages, including 14 integration method labs covering odd sine/cosine powers, even powers, different frequencies, rational expressions, tan/sec, cot/csc, mixed functions, trigonometric substitutions, cyclic parts and reduction formulas. Existing note page indexes remain stable because the new pages are appended.

Integration exercises in Chapters 8–10 now have multi-label sin/cos, tan/sec, cot/csc, mixed-function and exponential/logarithmic filters. Original methods are retained in `originalType` and method tags. 36 textbook source-image pages were re-read with OCR, aligning 371 of 379 exercise starts to question numbers and reducing neighbouring-question contamination. Ambiguous extraction is not used to infer odd/even exponents. Classification evidence is recorded in `content/integration-classification-audit.json`.

Run `node scripts/validate-content.cjs` and `node scripts/validate-refinement.cjs` to check the full bank, formulas, function filters, method selector, precise regression examples and 106-page lesson collection. All 2,473 question IDs are retained.
