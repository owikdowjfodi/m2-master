## 2026-11-10 — Deeper notes and function-specific exercises

- Added 29 deep worked lessons for 106 total pages; Chapter 9 has 14 new integration method labs.
- Added independent function-family and method filters, precise sin/cos, tan/sec and cot/csc section labels, and direct practice links from worked lessons.
- Re-read 36 textbook integration pages and aligned 371 exercise starts to reduce neighbouring-question contamination in function labels and image crops.
- Preserved all question IDs, original method metadata, answer images and existing note reading-marker indexes.

## 2026-11-09 — bk1.pdf past-paper question bank

- Imported 525 distinct questions from 533 occurrences in the 254-page bk1.pdf; merged 8 repeated paper references and exposed alternate source versions.
- Classified by teaching chapter and question type; retained original year, paper, question number, marks and legacy/extension labels.
- Matched 495 printed answer excerpts with two-column-aware cropping, and preserved cross-page questions.
- Added a past-paper source filter. Question bank total is 2,473; existing 77 English note pages and all prior IDs are preserved.

## 2026-11-09 — Source-based English Concepts & Formulas

- Classified all 17 Drive M2/Notes PDFs (479 pages) against the existing 15 teaching chapters.
- Replaced 66 Chinese pages with 77 English pages: definitions, conditions, formula derivations, worked examples, common mistakes and self-check disclosures.
- Added per-page source references, chapter-specific source guides, an editable source manifest, and three original mathematical SVG diagrams.
- Labelled source extensions and corrected the concavity wording; differentiated the duplicated source section 7.4 by title.
- Preserved all 1,948 question IDs, source assets and account-free answer flows; versioned note reading markers.

# Content expansion 2026 11 09

Imported the questions represented in the expanded Word draft using their original PDFs, preserving source mathematical layout rather than displaying damaged text extraction. Added 1,903 questions, chapter/type classification, source references, 12-question pagination and source/format/search controls. Retained all 45 original questions and their IDs.

Replaced the initial short concept section with 66 pages of substantive notes across all 15 chapters and a prerequisite area. Added contents, complete examples, self-check answers and reading markers. Kept Concepts & Formulas fixed first in each chapter.

No authentication, roles, cloud upload or paid service was introduced. Original typed paper solutions remain distinct from questions; duplicated handwritten attempt pages are excluded.
