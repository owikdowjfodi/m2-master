const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');const root=path.resolve(__dirname,'..');const katex=require(path.join(root,'dist/vendor/katex/katex.min.js'));const ctx={};vm.createContext(ctx);for(const file of ['data.js','lessons.js','imported-bank.js','content-adapter.js'])vm.runInContext(fs.readFileSync(path.join(root,'docs',file),'utf8'),ctx);vm.runInContext('this.data={chapters:CHAPTERS,bank:IMPORTED_BANK,lessons:LESSONS}',ctx);const {chapters,bank,lessons}=ctx.data;assert.equal(chapters.length,16);assert.equal(bank.sources.length,20);assert.equal(bank.questions.length,2428);const all=chapters.flatMap(c=>c.questions);assert.equal(new Set(all.map(q=>q.id)).size,all.length);assert.equal(all.length,2473);let formulas=0,assets=0;
function render(text){for(const m of String(text).matchAll(/\$\$([\s\S]*?)\$\$|\$([^$\n]+)\$/g)){try{katex.renderToString(m[1]||m[2],{throwOnError:true,strict:'error'});formulas++;}catch(e){throw new Error((m[1]||m[2])+'\n'+e.message);}}}
for(const c of chapters){assert(lessons[c.id].length>=2);for(const p of lessons[c.id]){assert(p.body.length>200);render(p.body);}for(const q of c.questions){assert.equal(q.chapter,c.id);if(q.sourceId)assert(q.assets.length>0,q.id+" has no source image");assert.equal(c.types[q.section],q.type);render(q.prompt);render(q.solution||'');render(q.explanation||'');for(const o of q.options||[])render(o);for(const a of [...q.assets||[],...q.solutionAssets||[]]){assert(a.bottom>a.top);if(a.left!==undefined){assert(a.left>=0&&a.right>a.left&&a.right<=a.width);}assert(a.top>=0&&a.bottom<=a.height);assert(fs.existsSync(path.join(root,'docs',a.src)),a.src);assets++;}}}
for(const s of bank.sources)assert.equal(bank.questions.filter(q=>q.sourceId===s.id).length,s.count);
console.log(JSON.stringify({chapters:15,prerequisiteAreas:1,importedQuestions:bank.questions.length,totalQuestions:all.length,notePages:Object.values(lessons).reduce((n,p)=>n+p.length,0),formulasRendered:formulas,assetReferences:assets,sourceFiles:bank.sources.length}));

const manifest=JSON.parse(fs.readFileSync(path.join(root,'content/notes-manifest.json'),'utf8'));
assert.equal(manifest.sources.length,17);assert.equal(new Set(manifest.sources.map(s=>s.file)).size,17);
assert.equal(manifest.sources.reduce((n,s)=>n+s.pages,0),479);
for(let ch=1;ch<=15;ch++)assert(manifest.sources.some(s=>s.chapters.includes(ch)),'Missing chapter source '+ch);
for(const pages of Object.values(lessons))for(const page of pages){assert(page.source&&page.source.length>20,'Missing note provenance');assert(!/[\u3400-\u9fff]/.test(page.body),'English note contains untranslated text');assert(page.body.includes(':::answer'),'Missing self-check answer');assert(page.body.includes('### Worked example'),'Missing worked example');assert(!page.body.includes('@source'),'Metadata leaked into body');}
assert(!fs.existsSync(path.join(root,'dist/qa-mobile.html')),'Temporary QA file would be published');
console.log('English notes: source coverage, page provenance, worked examples and self-checks verified.');

const bk=bank.questions.filter(q=>q.sourceId==='pastpaper-bk1');
assert.equal(bk.length,525);assert.equal(new Set(bk.map(q=>q.paperReference)).size,525);
assert.equal(bk.reduce((n,q)=>n+q.sourceOccurrences.length,0),533);
assert(bk.some(q=>q.assets.length>1),'Missing cross-page question');
assert(bk.filter(q=>q.solutionAssets?.length).length>=490,'Printed answers omitted');
for(const q of bk){assert(q.sourcePage>=2&&q.sourcePage<=248);assert(q.marks===null||q.marks>0);for(const a of q.assets)assert(!a.left,'Questions should use the full-width source layout');}
console.log('bk1: 533 question occurrences, 525 unique references, 8 repeated occurrences merged; multi-page questions and column-cropped answers verified.');
