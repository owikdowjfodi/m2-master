import json,re,collections
from pathlib import Path
R=Path(__file__).resolve().parents[1]
b=json.loads((R/'content/imported-bank.json').read_text())
# Initial editorial estimates. Type identifies the mathematical method; evidence
# from the actual question adds reasoning demands. Marks/length do not assign levels.
basic=['基本導數','基本不定積分','向量運算','向量大小','弧度、','函數增量','二項展開','三角函數與象限']
advanced=['解的分類','幾何證明','技巧與證明','分部積分與遞推','三角幾何綜合','積分技巧綜合']
for q in b['questions']:
 t=q['type'];x=q.get('searchText','').lower();reasons=[]
 lv=2
 if any(v in t for v in basic):lv=1;reasons.append('直接公式／基本運算題型')
 elif any(v in t for v in advanced):lv=4;reasons.append('須選擇方法並處理綜合推理')
 elif any(v in t for v in ['證明','綜合','投影','相關變率','最值','代換','旋轉體','面積與','隱函數','三角積分','定積分 ·']):lv=3;reasons.append('需要方法選擇或連接多個概念')
 else:reasons.append('標準方法及數步運算')
 proof=len(re.findall(r'\b(prove|show that|justify|explain why)\b',x))
 if proof and lv<3:lv=3;reasons.append('題目要求論證')
 if proof>=2 and lv>=3:lv=min(5,lv+1);reasons.append('包含多個論證要求')
 if re.search(r'\b(hence or otherwise|deduce|all possible|number of solutions|recurrence|reduction formula)\b',x):lv=min(5,lv+1);reasons.append('需延伸前部結果或分類討論')
 if q.get('extension'):lv=max(4,lv);reasons.append('含延伸／舊課程內容')
 if len(q.get('functionFamilies',[]))>1 and lv<4:lv+=1;reasons.append('涉及多種函數，需先轉換形式')
 if lv==1 and re.search(r'\b(hence|prove|show|maximum|minimum|unknown|parameter)\b',x):lv=2;reasons.append('另有推理或未知參數')
 q.update(difficultyLevel=lv,difficulty='Lv'+str(lv)+' '+'★'*lv,difficultyReason='；'.join(reasons),difficultyStatus='estimated')
(R/'content/imported-bank.json').write_text(json.dumps(b,ensure_ascii=False,separators=(',',':')))
(R/'content/difficulty-audit.json').write_text(json.dumps({'rubricVersion':1,'status':'Initial editorial estimates based on question type and available question text; not HKEAA ratings or empirical student performance.','counts':dict(collections.Counter(q['difficultyLevel'] for q in b['questions'])),'questions':[{'id':q['id'],'level':q['difficultyLevel'],'reason':q['difficultyReason']} for q in b['questions']]},ensure_ascii=False,indent=2))
print(collections.Counter(q['difficultyLevel'] for q in b['questions']))
