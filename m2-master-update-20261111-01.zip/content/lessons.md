# 0
## Surds: definitions, domains and exact values
@source Supplementary prerequisite note; not a separate chapter in the 17 supplied PDFs.
### Definition and conditions
For a real number $a\ge0$, $\sqrt a$ denotes the non-negative square root. Squaring loses the sign of the original number, so

$$ (\sqrt a)^2=a,\qquad \sqrt{x^2}=|x|. $$

For $a,b\ge0$, $\sqrt{ab}=\sqrt a\sqrt b$; if also $b>0$, $\sqrt{a/b}=\sqrt a/\sqrt b$. These rules do not distribute over addition.
### Worked example — simplify before collecting
Simplify $3\sqrt{12}-2\sqrt{27}+\sqrt{75}$.

1. Extract square factors: $\sqrt{12}=2\sqrt3$, $\sqrt{27}=3\sqrt3$, $\sqrt{75}=5\sqrt3$.
2. Collect like surds: $6\sqrt3-6\sqrt3+5\sqrt3=5\sqrt3$.
3. Retain this exact form when an exact answer is requested.
### Common mistake
$\sqrt{a+b}$ is generally not $\sqrt a+\sqrt b$. Likewise $\sqrt{9x^2}=3|x|$, not always $3x$.
### Self-check
Simplify $\sqrt{16t^2}$ when $t<0$.
:::answer
$4|t|=-4t$. The answer is non-negative, as a principal square root must be.
:::
## Conjugates, rationalisation and extraneous roots
@source Supplementary prerequisite note; supports algebraic limits in S4 Ch 4.
### Why the conjugate works
The difference-of-squares identity gives

$$ (a+b\sqrt c)(a-b\sqrt c)=a^2-b^2c. $$

Multiply numerator and denominator by the same non-zero expression. This preserves the value while removing a surd from the denominator.
### Worked example — exact rationalisation
For $2/(\sqrt5-1)$, the conjugate is $\sqrt5+1$:

$$ \frac2{\sqrt5-1}=\frac{2(\sqrt5+1)}{5-1}=\frac{\sqrt5+1}{2}. $$

Verify by multiplying the result by $\sqrt5-1$: the product is $2$.
### Worked example — a radical equation
Solve $\sqrt{x+1}=x-1$. Both sides can agree only when $x\ge1$. Squaring gives $x+1=x^2-2x+1$, hence $x(x-3)=0$. The candidate $x=0$ violates the original condition. Substitution confirms $x=3$.
### Self-check
Rationalise $1/(2+\sqrt3)$ and check the answer.
:::answer
$2-\sqrt3$, because $(2+\sqrt3)(2-\sqrt3)=1$. Always check denominators before cancellation.
:::
# 1
## Summation notation and standard finite sums
@source S4 Ch 1 §1.1, PDF pp. 1–3.
### Read the notation
In $\sum_{r=1}^{n}a_r$, $r$ is a dummy index, $1$ the lower limit and $n$ the upper limit. Both endpoints are included. The index can be renamed without changing the sum.

$$ \sum_{r=1}^n(\alpha a_r+\beta b_r)=\alpha\sum_{r=1}^na_r+\beta\sum_{r=1}^nb_r. $$

For positive integers $n$:

$$ \sum_{r=1}^n1=n,\quad \sum_{r=1}^nr=\frac{n(n+1)}2,\quad \sum_{r=1}^nr^2=\frac{n(n+1)(2n+1)}6,\quad \sum_{r=1}^nr^3=\left[\frac{n(n+1)}2\right]^2. $$
### Worked example — a shifted lower limit
Find $\sum_{r=3}^{8}(2r-1)$.

1. Use linearity: $2\sum_{r=3}^{8}r-\sum_{r=3}^{8}1$.
2. $\sum_{r=3}^{8}r=8(9)/2-(1+2)=33$; there are $8-3+1=6$ terms.
3. The answer is $2(33)-6=60$.
### Self-check
Is $\sum_{r=4}^{n}1=n-4$?
:::answer
No. There are $n-3$ terms, provided $n\ge4$. Count inclusively.
:::
## The principle of mathematical induction
@source S4 Ch 1 §1.2, PDF pp. 3–5.
### What an induction proof establishes
Let $P(n)$ be a precisely stated proposition for every integer $n\ge n_0$. Prove a starting case and a step that works for an arbitrary subsequent integer:

$$ P(n_0),\qquad P(k)\Longrightarrow P(k+1)\quad(k\ge n_0). $$

The starting case begins the chain. The implication ensures it never stops. Checking several values alone is not a proof for infinitely many integers.
### Worked example — sum of odd numbers
Prove $\sum_{r=1}^n(2r-1)=n^2$ for positive integers $n$.

1. Base case $n=1$: $1=1^2$.
2. Assume $\sum_{r=1}^k(2r-1)=k^2$ for an arbitrary positive integer $k$.
3. For $k+1$, the left side is $k^2+[2(k+1)-1]=k^2+2k+1=(k+1)^2$.
4. Therefore the statement holds for every positive integer by mathematical induction.
### Common mistake
The induction hypothesis may be used inside the step. The desired statement $P(k+1)$ may not be assumed.
### Self-check
If the required range is $n\ge5$, what changes?
:::answer
Verify $P(5)$ and prove the implication for arbitrary integers $k\ge5$. A base case at $1$ alone would not establish the specified chain unless all intervening steps were valid.
:::
## Induction for polynomial sums
@source S4 Ch 1 §1.3, PDF pp. 5–31: finite-sum proof methods.
### Method — isolate the new term
When the upper limit increases from $k$ to $k+1$, first separate the new term. Then replace only the old sum using the hypothesis. Keep the target factorisation visible.
### Worked example — sum of squares
Prove $\sum_{r=1}^nr^2=n(n+1)(2n+1)/6$.

1. At $n=1$, both sides equal $1$.
2. Assume the formula for $n=k$.
3. At $n=k+1$,

$$ \begin{aligned}\sum_{r=1}^{k+1}r^2&=\frac{k(k+1)(2k+1)}6+(k+1)^2\\&=\frac{(k+1)[k(2k+1)+6(k+1)]}{6}\\&=\frac{(k+1)(2k^2+7k+6)}6\\&=\frac{(k+1)(k+2)(2k+3)}6.\end{aligned} $$

This is the required expression with $n=k+1$. Conclude by induction.
### Common mistake
If the upper limit is $2n$, the next stage introduces two terms, not one. The summand may also depend on $n$; check this before copying the standard pattern.
### Self-check
What must be added to $\sum_{r=1}^{2k}r$ to obtain $\sum_{r=1}^{2k+2}r$?
:::answer
Add $(2k+1)+(2k+2)$. The upper limit changes by two.
:::
## Geometric sums, divisibility and recurrence proofs
@source S4 Ch 1 §1.3, PDF pp. 5–31: identity and recursive proof strategies.
### Finite geometric sums
For $q\ne1$,

$$ 1+q+\cdots+q^{n-1}=\frac{1-q^n}{1-q}. $$

For $q=1$, the sum is $n$. To prove the formula by induction, add $q^k$ to the assumed expression, combine over $1-q$, and obtain $(1-q^{k+1})/(1-q)$.
### Worked example — divisibility
Prove $7^n-1$ is divisible by $6$ for every positive integer $n$.

1. At $n=1$, $7-1=6$.
2. Suppose $7^k-1=6m$ for an integer $m$.
3. $7^{k+1}-1=7(7^k-1)+6=6(7m+1)$.
4. Since $7m+1$ is an integer, divisibility holds at $k+1$. Conclude by induction.
### Recurrences
For a recursively defined sequence, first verify the claimed formula at the initial index, substitute the hypothesis into the recurrence, and simplify to the claimed next value. Never replace the recurrence with an unproved pattern.
### Self-check
A sequence satisfies $a_1=2$ and $a_{n+1}=3a_n$. Propose and verify a formula.
:::answer
$a_n=2\cdot3^{n-1}$. The initial value is $2$; if true at $k$, then $a_{k+1}=3(2\cdot3^{k-1})=2\cdot3^k$.
:::
## Inequalities and choosing the induction start
@source S4 Ch 1 §1.2–1.3, PDF pp. 3–31: induction framework; original supplementary example.
### The inequality step must preserve direction
An induction proof of an inequality often needs a second estimate after the hypothesis. State when that estimate is valid. Multiplying by a negative quantity reverses an inequality.
### Worked example — exponential growth
Prove $2^n\ge n^2$ for integers $n\ge4$.

1. Base case: $2^4=16=4^2$.
2. Assume $2^k\ge k^2$ for an arbitrary integer $k\ge4$.
3. Then $2^{k+1}=2\cdot2^k\ge2k^2$.
4. To reach $(k+1)^2$, observe $2k^2-(k+1)^2=k^2-2k-1=(k-1)^2-2>0$ for $k\ge4$.
5. Hence $2^{k+1}\ge(k+1)^2$, so induction completes the proof.
### Common mistake
$2^k\ge k^2$ alone does not justify the next conclusion without comparing $2k^2$ with $(k+1)^2$. A correct starting index matters: $n=3$ fails.
### Self-check
Why can this proof not establish the claim for all $n\ge1$?
:::answer
The claim is false at $n=3$, and the comparison used in the induction step was justified only for $k\ge4$.
:::
# 2
## Factorials, combinations and Pascal’s identity
@source S4 Ch 2 §2.1, PDF pp. 1–4.
### Definitions and restrictions
For a non-negative integer $n$, $n!=n(n-1)\cdots1$, with $0!=1$. The number of ways to choose $r$ objects from $n$ distinct objects without regard to order is

$$ {n\choose r}=\frac{n!}{r!(n-r)!}\quad(0\le r\le n). $$

Two useful identities are ${n\choose r}={n\choose n-r}$ and ${n\choose r}+{n\choose r+1}={n+1\choose r+1}$.
### Why Pascal’s identity holds
Choose $r+1$ people from $n+1$. Separate the choices into those excluding one named person (${n\choose r+1}$) and those including that person (${n\choose r}$). These disjoint cases exhaust all possibilities.
### Worked example
Compute ${8\choose3}$ without evaluating large factorials:

$$ {8\choose3}=\frac{8\cdot7\cdot6}{3\cdot2\cdot1}=56. $$

Symmetry also gives ${8\choose5}=56$.
### Self-check
Explain why ${n\choose0}={n\choose n}=1$.
:::answer
There is one way to choose nothing and one way to choose everything. The factorial formula agrees because $0!=1$.
:::
## The binomial theorem and the general term
@source S4 Ch 2 §2.2, PDF pp. 4–20.
### Statement
For a non-negative integer $n$,

$$ (a+b)^n=\sum_{r=0}^n{n\choose r}a^{n-r}b^r. $$

There are $n+1$ terms. The term indexed by $r$ is the $(r+1)$th term:

$$ T_{r+1}={n\choose r}a^{n-r}b^r. $$

The coefficient counts which $r$ of the $n$ brackets contribute $b$; the remaining brackets contribute $a$. This explains the theorem combinatorially.
### Worked example — signs matter
Expand $(2-x)^4$:

$$ (2-x)^4=16-32x+24x^2-8x^3+x^4. $$

For instance, the $x^2$ term is ${4\choose2}2^2(-x)^2=24x^2$. The minus sign belongs inside the powered factor.
### Check
At $x=0$, both expressions give $16$. At $x=2$, the expansion sums to $0$.
### Self-check
Find the fourth term of $(1+3x)^5$.
:::answer
Use $r=3$: $T_4={5\choose3}(3x)^3=270x^3$. Using $r=4$ would give the fifth term.
:::
## Specified coefficients and constant terms
@source S4 Ch 2 §2.2, PDF pp. 4–20: general-term applications.
### Method
Write the general term, simplify its power of $x$, equate that exponent to the required power, and check the resulting $r$ is an integer in $0\le r\le n$.
### Worked example — a constant term
Find the term independent of $x$ in $(x^2+2/x)^6$, where $x\ne0$.

$$ T_{r+1}={6\choose r}(x^2)^{6-r}(2/x)^r={6\choose r}2^r x^{12-3r}. $$

A constant requires $12-3r=0$, so $r=4$. This is allowed. The constant term is ${6\choose4}2^4=15(16)=240$.
### Worked example — combining two expansions
Find the coefficient of $x^2$ in $(1+2x)^3(1-x)^2$. The needed coefficients are $1,6,12$ from the first factor and $1,-2,1$ from the second. Pair powers adding to $2$:

$$ [x^2]=12(1)+6(-2)+1(1)=1. $$
### Common mistake
The coefficient is a number; the term includes the power of $x$. Some requested powers have no term because the exponent equation has no permitted integer solution.
### Self-check
Can $(x^2+x^{-1})^4$ contain an $x^0$ term?
:::answer
The exponent is $8-3r$. Setting it to zero gives $r=8/3$, not an integer. Therefore the constant coefficient is zero.
:::
## Coefficient sums and identities
@source S4 Ch 2 §2.2, PDF pp. 4–20: substitutions and applications.
### Substitution turns expansions into identities
Setting $a=b=1$ in the binomial theorem gives

$$ \sum_{r=0}^n{n\choose r}=2^n. $$

For $n\ge1$, substituting $a=1,b=-1$ gives $\sum_{r=0}^n(-1)^r{n\choose r}=0$. Adding and subtracting show that the even-index and odd-index coefficient sums are both $2^{n-1}$.
### Worked example — sum of coefficients
For $P(x)=(2-3x)^5$, the sum of coefficients is $P(1)=(-1)^5=-1$. The alternating sum of coefficients is $P(-1)=5^5=3125$. Expanding every term is unnecessary.
### Reasoning with coefficient comparison
From $(1+x)^m(1+x)^n=(1+x)^{m+n}$, compare coefficients of $x^r$:

$$ \sum_j{m\choose j}{n\choose r-j}={m+n\choose r}, $$

where only indices with both combinations defined are included. This is a useful extension of the general-term method, rather than another formula to memorise blindly.
### Self-check
What is the sum of coefficients of $(1-2x)^4$?
:::answer
Set $x=1$: $(1-2)^4=1$. Evaluating at $x=0$ would give only the constant term.
:::
# 3
## Radians, arcs, sectors and segments
@source S4 Ch 3A §3.1, PDF pp. 1–3; Trigonometric Functions Formulae Table, p. 1.
### Definition
One radian is the angle subtended at a circle’s centre by an arc equal in length to the radius. A full turn is $2\pi$ radians:

$$ 180^\circ=\pi\text{ rad},\qquad \theta_{\rm rad}=\theta_{\rm deg}\frac\pi{180}. $$

For radius $r$ and a non-negative central angle $\theta$ in radians,

$$ s=r\theta,\qquad A_{\rm sector}=\frac12r^2\theta. $$

The sector area follows from the fraction $\theta/(2\pi)$ of the whole circle. For $0\le\theta\le\pi$, the minor segment area is $\tfrac12r^2(\theta-\sin\theta)$, found by subtracting the isosceles triangle.
### Worked example
A sector has $r=6$ cm and angle $60^\circ=\pi/3$. Its arc length is $2\pi$ cm and its area is $6\pi$ cm². Its perimeter is $12+2\pi$ cm, because the two radii are included.
### Self-check
An arc of length $5$ has radius $4$. Find its central angle.
:::answer
$\theta=s/r=5/4$ radians. The formulas $s=r\theta$ and $\tfrac12r^2\theta$ require radian measure.
:::
## The unit circle and six trigonometric functions
@source S4 Ch 3A §3.2, PDF pp. 4–13; Formulae Table, p. 1.
### Definitions beyond right triangles
A point on the unit circle at directed angle $\theta$ has coordinates $(\cos\theta,\sin\theta)$. Hence

$$ \tan\theta=\frac{\sin\theta}{\cos\theta},\quad \sec\theta=\frac1{\cos\theta},\quad \csc\theta=\frac1{\sin\theta},\quad \cot\theta=\frac{\cos\theta}{\sin\theta}. $$

A quotient is defined only where its denominator is non-zero. Thus $\tan,\sec$ are undefined at $\pi/2+k\pi$; $\cot,\csc$ are undefined at $k\pi$, for integer $k$.
### Worked example — quadrant and exact values
If $\theta$ lies in quadrant II and $\sin\theta=3/5$, then $\cos\theta=-\sqrt{1-9/25}=-4/5$. Therefore $\tan\theta=-3/4$, $\sec\theta=-5/4$, $\csc\theta=5/3$ and $\cot\theta=-4/3$.
### Common mistake
A positive sine value does not determine the sign of cosine. Use the quadrant before choosing a square root.
### Self-check
Find all undefined values of $\tan\theta$ in $0\le\theta<2\pi$.
:::answer
$\theta=\pi/2$ and $3\pi/2$, where cosine is zero.
:::
## Graphs, periods, symmetry and transformations
@source S4 Ch 3A §3.2, PDF pp. 4–13; even/odd functions also in S4 Ch 6A §6.4, PDF pp. 26–47.
### Read a transformed graph
For $y=A\sin(Bx+C)+D$, with $B\ne0$, the amplitude is $|A|$, period is $2\pi/|B|$, midline is $y=D$ and horizontal shift is $-C/B$. Cosine has the same amplitude and period rules. Tangent has period $\pi/|B|$ and no amplitude.

$$ \sin(-x)=-\sin x,\qquad \cos(-x)=\cos x,\qquad \tan(-x)=-\tan x. $$

An even function satisfies $f(-x)=f(x)$ and is symmetric about the $y$-axis. An odd function satisfies $f(-x)=-f(x)$ and has rotational symmetry about the origin. Its domain must also be symmetric.
### Worked example
For $y=2\sin(3x-\pi)+1$, write $3x-\pi=3(x-\pi/3)$. The amplitude is $2$, period $2\pi/3$, shift $\pi/3$ to the right, and range $[-1,3]$.
### Self-check
Is $f(x)=x^3+x$ even, odd or neither?
:::answer
$f(-x)=-x^3-x=-f(x)$, so it is odd. A sum of odd functions is odd on a symmetric domain.
:::
## Related angles and solving trigonometric equations
@source S4 Ch 3A §3.2–3.3, PDF pp. 4–28; Formulae Table, p. 1.
### Symmetry supplies all solutions
For integer $k$,

$$ \sin x=\sin\alpha\Rightarrow x=\alpha+2k\pi\text{ or }\pi-\alpha+2k\pi, $$

$$ \cos x=\cos\alpha\Rightarrow x=\pm\alpha+2k\pi,\qquad \tan x=\tan\alpha\Rightarrow x=\alpha+k\pi. $$

Use these after finding a reference angle. Apply the stated interval to the original variable, especially when the equation contains $2x$ or $3x$.
### Worked example
Solve $\sin2x=\sqrt3/2$ for $0\le x<2\pi$.

1. The transformed angle satisfies $0\le2x<4\pi$.
2. Within this interval, $2x=\pi/3,2\pi/3,7\pi/3,8\pi/3$.
3. Divide all values by two: $x=\pi/6,\pi/3,7\pi/6,4\pi/3$.
### Common mistake
Dividing by a trig factor can discard solutions where that factor is zero. Factor the equation first and solve each permitted factor separately.
### Self-check
Solve $\cos x=0$ on $[-\pi,\pi]$.
:::answer
$x=-\pi/2,\pi/2$. The endpoints do not satisfy the equation.
:::
# 4
## Reciprocal, quotient and Pythagorean identities
@source S4 Ch 3A §3.3, PDF pp. 14–28; Formulae Table, p. 1.
### Derive the families from the unit circle
Since $(\cos x,\sin x)$ lies on the unit circle,

$$ \sin^2x+\cos^2x=1. $$

Divide by $\cos^2x$ where $\cos x\ne0$, or by $\sin^2x$ where $\sin x\ne0$:

$$ 1+\tan^2x=\sec^2x,\qquad 1+\cot^2x=\csc^2x. $$

An identity holds at every point in its common domain. Cancelling factors does not make excluded points valid.
### Worked example — prove from one side
For $\sin x\ne0$ and $\cos x\ne0$,

$$ \frac{\sec^2x-1}{\csc^2x-1}=\frac{\tan^2x}{\cot^2x}=\tan^4x. $$

The denominator on the left is $\cot^2x$, so its non-zero condition must be retained.
### Common mistake
$\sin^2x$ means $(\sin x)^2$, not $\sin(x^2)$. When proving an identity, transform one side to the other rather than assuming the equality you are proving.
### Self-check
Simplify $(1-\cos^2x)/\sin x$ on its original domain.
:::answer
It equals $\sin x$ for $\sin x\ne0$. The simplified expression is defined more widely, but the original expression is not.
:::
## Compound-angle formulas: meaning and derivation
@source S4 Ch 3B §3.4, PDF pp. 1–6; Formulae Table, p. 1.
### Formula family

$$ \sin(A\pm B)=\sin A\cos B\pm\cos A\sin B, $$

$$ \cos(A\pm B)=\cos A\cos B\mp\sin A\sin B, $$

$$ \tan(A\pm B)=\frac{\tan A\pm\tan B}{1\mp\tan A\tan B}. $$

The tangent expression requires both constituent tangents and its denominator to be defined. Sine and cosine formulas have no such denominator restriction.
### Why the sine formula is plausible
The source derives it geometrically by splitting a triangle’s area into two pieces. Each piece contributes a height component: one gives $\sin A\cos B$ and the other $\cos A\sin B$. Directed-angle extensions then cover other angles.
### Worked example — an exact value

$$ \sin75^\circ=\sin(45^\circ+30^\circ)=\frac{\sqrt2}{2}\frac{\sqrt3}{2}+\frac{\sqrt2}{2}\frac12=\frac{\sqrt6+\sqrt2}{4}. $$

For cosine, the corresponding sum formula subtracts the product of sines.
### Self-check
Find $\cos15^\circ$ exactly.
:::answer
$\cos(45^\circ-30^\circ)=(\sqrt6+\sqrt2)/4$. The minus-angle cosine formula uses a plus between the products.
:::
## Double angles and power reduction
@source S4 Ch 3B §3.5, PDF pp. 7–11; Formulae Table, p. 1.
### Derive by setting the angles equal
Set $A=B=x$ in the compound-angle formulas:

$$ \sin2x=2\sin x\cos x, $$

$$ \cos2x=\cos^2x-\sin^2x=1-2\sin^2x=2\cos^2x-1, $$

$$ \tan2x=\frac{2\tan x}{1-\tan^2x} $$

where the tangent form is defined. Rearranging the cosine alternatives gives power-reduction identities:

$$ \sin^2x=\frac{1-\cos2x}{2},\qquad \cos^2x=\frac{1+\cos2x}{2}. $$

These convert squared trigonometric functions into forms that are easier to integrate.
### Worked example
If $\tan x=3/4$ and $x$ is in quadrant III, both sine and cosine are negative. Thus $\sin x=-3/5$, $\cos x=-4/5$, so $\sin2x=24/25$ and $\cos2x=7/25$.
### Common mistake
From $\cos2x=2\cos^2x-1$, recovering $\cos x$ requires a sign from the quadrant. A square root alone gives only a magnitude.
### Self-check
Express $\sin^2(3x)$ without a squared sine.
:::answer
$\sin^2(3x)=(1-\cos6x)/2$. The angle doubles as well as the coefficient changing.
:::
## Sum-to-product and product-to-sum
@source S4 Ch 3B §3.6, PDF pp. 12–23; Formulae Table, p. 1.
### Adding compound-angle formulas
Add and subtract the formulas for $A+B$ and $A-B$ to obtain

$$ 2\sin A\cos B=\sin(A+B)+\sin(A-B), $$

$$ 2\cos A\cos B=\cos(A+B)+\cos(A-B), $$

$$ 2\sin A\sin B=\cos(A-B)-\cos(A+B). $$

Substitute $A=(u+v)/2$, $B=(u-v)/2$ to reverse the process:

$$ \sin u+\sin v=2\sin\frac{u+v}{2}\cos\frac{u-v}{2}, $$

$$ \sin u-\sin v=2\cos\frac{u+v}{2}\sin\frac{u-v}{2}, $$

$$ \cos u+\cos v=2\cos\frac{u+v}{2}\cos\frac{u-v}{2}, $$

$$ \cos u-\cos v=-2\sin\frac{u+v}{2}\sin\frac{u-v}{2}. $$
### Worked example
$\sin5x+\sin x=2\sin3x\cos2x$. Thus the equation $\sin5x+\sin x=0$ becomes $\sin3x=0$ or $\cos2x=0$. Factoring preserves both branches; dividing by either factor would lose solutions.
### Self-check
Convert $\sin3x\sin x$ into a difference of cosines.
:::answer
$\tfrac12(\cos2x-\cos4x)$. The order is difference angle minus sum angle.
:::
## The auxiliary-angle method and ranges
@source S4 Ch 3B §3.4–3.6, PDF pp. 1–23: compound-angle applications.
### Combine a sine and cosine of the same angle
For $(a,b)\ne(0,0)$, set $R=\sqrt{a^2+b^2}>0$ and choose $\alpha$ with $\cos\alpha=a/R$, $\sin\alpha=b/R$. Then

$$ a\sin x+b\cos x=R\sin(x+\alpha). $$

This follows by expanding the right side. Choose the correct quadrant for $\alpha$; $\tan\alpha=b/a$ alone is ambiguous.
### Worked example — range and equation
$3\sin x+4\cos x=5\sin(x+\alpha)$, where $\cos\alpha=3/5$, $\sin\alpha=4/5$. The range is $[-5,5]$. Therefore $3\sin x+4\cos x=6$ has no real solutions.

For $3\sin x+4\cos x=5$, equality requires $x+\alpha=\pi/2+2k\pi$. Thus $x=\pi/2-\alpha+2k\pi$ for integer $k$.
### Common mistake
The full range may not occur if $x$ is restricted to a short interval. Evaluate endpoints and stationary candidates in that interval when necessary.
### Self-check
Find the full real range of $2-\sin x+\sqrt3\cos x$.
:::answer
The amplitude is $\sqrt{1+3}=2$. After shifting upwards by $2$, the range is $[0,4]$.
:::
# 5
## Limits, function values and one-sided behaviour
@source S4 Ch 4 §4.1, PDF pp. 1–8.
### What a limit describes
$\lim_{x\to a}f(x)=L$ means that values of $f(x)$ approach $L$ as $x$ approaches $a$ through the domain, without requiring $x=a$. The value $f(a)$ may be different or undefined.

$$ \lim_{x\to a}f(x)=L\quad\Longleftrightarrow\quad\lim_{x\to a^-}f(x)=\lim_{x\to a^+}f(x)=L. $$

Continuity at $a$ additionally requires $f(a)$ to exist and equal this limit.
### Worked example — a removable hole
For $f(x)=(x^2-1)/(x-1)$ with $x\ne1$, factoring gives $f(x)=x+1$. Hence $\lim_{x\to1}f(x)=2$, although the original formula has no value at $1$. Defining $f(1)=2$ would fill the hole continuously.
### Worked example — a jump
For $g(x)=|x|/x$, the left-hand limit at zero is $-1$ and the right-hand limit is $1$. The two-sided limit does not exist.
### Common mistake
A table of nearby values suggests behaviour; it does not replace an algebraic justification. The form $0/0$ signals more work, not an answer.
### Self-check
Does changing a function at one point necessarily change its limit there?
:::answer
No. The limit concerns nearby values. A single changed function value can affect continuity without changing the limit.
:::
## Algebraic limits: factorisation and rationalisation
@source S4 Ch 4 §4.1, PDF pp. 1–8.
### Limit laws and their conditions
If $f\to L$ and $g\to M$, then $f+g\to L+M$ and $fg\to LM$. The quotient tends to $L/M$ only when $M\ne0$. For continuous elementary expressions, direct substitution is the first check.
### Worked example — factor and cancel

$$ \lim_{x\to2}\frac{x^2-4}{x-2}=\lim_{x\to2}(x+2)=4. $$

Cancellation is legitimate for nearby $x\ne2$; a limit does not require the cancelled expression to be defined at the limiting point.
### Worked example — use a conjugate

$$ \begin{aligned}\lim_{h\to0}\frac{\sqrt{1+h}-1}{h}&=\lim_{h\to0}\frac{(1+h)-1}{h(\sqrt{1+h}+1)}\\&=\lim_{h\to0}\frac1{\sqrt{1+h}+1}=\frac12.\end{aligned} $$

Both numerator and denominator were multiplied by the same conjugate. The remaining denominator approaches $2$, so the quotient law now applies.
### Common mistake
Do not cancel across addition: $(x^2+2)/(x+2)$ does not become $x$. Factor a common multiplicative factor first.
### Self-check
Find $\lim_{x\to3}(x^2-9)/(x^2-x-6)$.
:::answer
Factor as $(x-3)(x+3)/[(x-3)(x+2)]$. The limit is $6/5$.
:::
## Limits at infinity and asymptotic reasoning
@source S4 Ch 4 §4.2, PDF pp. 9–13.
### Compare dominant powers
For a rational function, divide numerator and denominator by the highest denominator power. If numerator degree is smaller, the limit is zero. Equal degrees give the ratio of leading coefficients. Larger numerator degree requires sign and growth analysis.
### Worked example

$$ \lim_{x\to\infty}\frac{3x^2-x+4}{2x^2+5}=\lim_{x\to\infty}\frac{3-1/x+4/x^2}{2+5/x^2}=\frac32. $$

Thus $y=3/2$ is a horizontal asymptote as $x\to\infty$.
### Radical expressions and absolute values
$\sqrt{x^2}=|x|$. Consequently

$$ \lim_{x\to-\infty}\frac{\sqrt{x^2+1}}{x}=\lim_{x\to-\infty}\frac{|x|\sqrt{1+1/x^2}}{x}=-1. $$

For a difference of large radicals, rationalise before taking the limit:

$$ \lim_{x\to\infty}(\sqrt{x^2+4x}-x)=\lim_{x\to\infty}\frac{4x}{\sqrt{x^2+4x}+x}=2. $$
### Self-check
Find $\lim_{x\to-\infty}x/\sqrt{x^2+9}$.
:::answer
$-1$, since $\sqrt{x^2+9}=|x|\sqrt{1+9/x^2}$ and $x/|x|=-1$ for negative $x$.
:::
## The number e, exponentials and natural logarithms
@source S4 Ch 4 §4.3, PDF pp. 14–25.
### A natural growth constant
The number $e$ can be characterised by

$$ e=\lim_{n\to\infty}\left(1+\frac1n\right)^n\approx2.71828. $$

$y=e^x$ is positive, increasing and passes through $(0,1)$. Its inverse is $y=\ln x$, defined for $x>0$. Therefore $\ln(e^x)=x$ for real $x$ and $e^{\ln x}=x$ for $x>0$.
### Logarithm laws
For $a,b>0$ and real $t$,

$$ \ln(ab)=\ln a+\ln b,\quad \ln(a/b)=\ln a-\ln b,\quad \ln(a^t)=t\ln a. $$

The positivity conditions matter. In particular, $\ln(a+b)$ does not split into a sum.
### Worked example
Solve $e^{2x}-3e^x+2=0$. Let $u=e^x>0$. Then $(u-1)(u-2)=0$, giving $u=1$ or $2$. Thus $x=0$ or $\ln2$. Both are permitted by the positive exponential substitution.
### Self-check
Simplify $\ln(e^3\sqrt e)$.
:::answer
$\ln(e^{7/2})=7/2$. Combine powers before applying the inverse relation.
:::
## Special limits and scaling the inner variable
@source S4 Ch 4 §4.3, PDF pp. 14–25.
### Two central limits
With angles in radians,

$$ \lim_{u\to0}\frac{\sin u}{u}=1,\qquad \lim_{u\to0}\frac{e^u-1}{u}=1. $$

Also $\lim_{u\to0}\ln(1+u)/u=1$, obtained by setting $v=\ln(1+u)$ so $u=e^v-1$. The geometric squeeze behind the sine limit compares triangle and sector areas near the origin.
### Worked example — make the standard form visible

$$ \lim_{x\to0}\frac{\sin3x}{5x}=\frac35\lim_{x\to0}\frac{\sin3x}{3x}=\frac35. $$

Similarly, $\lim_{x\to0}(e^{4x}-1)/x=4$. For the cosine limit, rationalise using its companion factor:

$$ \frac{1-\cos x}{x^2}=\frac{\sin^2x}{x^2(1+\cos x)}\longrightarrow\frac12. $$
### Common mistake
The sine limit equals $1$ only in radian measure. Also, a numerator such as $e^{4x}$ without subtracting $1$ does not have the same limiting structure.
### Self-check
Evaluate $\lim_{x\to0}\ln(1+2x)/(3x)$.
:::answer
Rewrite it as $\tfrac23\,\ln(1+2x)/(2x)$. The result is $2/3$.
:::
# 6
## The derivative from first principles
@source S4 Ch 5A §5.1, PDF pp. 1–2.

:::diagram secant
:::

### From a secant to a tangent
For points $P(a,f(a))$ and $Q(a+h,f(a+h))$, the secant slope is the average rate of change over the interval. If its limit exists as $h\to0$, it defines the derivative at $a$:

$$ f'(a)=\lim_{h\to0}\frac{f(a+h)-f(a)}h. $$

The derivative is an instantaneous rate and the tangent’s gradient. Notations include $f'(x)$, $y'$ and $dy/dx$.
### Worked example — differentiate a square
For $f(x)=x^2$,

$$ \frac{f(x+h)-f(x)}h=\frac{(x+h)^2-x^2}{h}=2x+h\quad(h\ne0). $$

Taking $h\to0$ gives $f'(x)=2x$. At $x=3$, the tangent slope is $6$.
### A derivative need not exist
For $f(x)=|x|$ at zero, the quotient $|h|/h$ tends to $-1$ from the left and $1$ from the right. The corner has no single tangent gradient.
### Self-check
Use first principles to differentiate $f(x)=3x+2$.
:::answer
$[3(x+h)+2-(3x+2)]/h=3$ for $h\ne0$. Hence $f'(x)=3$.
:::
## Power, constant and linearity rules
@source S4 Ch 5A §5.2, PDF pp. 2–15.
### Basic derivatives

$$ \frac{d}{dx}c=0,\qquad \frac{d}{dx}x^n=nx^{n-1},\qquad (au+bv)'=au'+bv'. $$

The power rule applies on intervals where the real power and derivative are defined. Negative and fractional powers require attention to zero and sign restrictions.
### Worked example — rewrite before differentiating
For $y=3x^4-2/x+5\sqrt x$ on $x>0$, write $y=3x^4-2x^{-1}+5x^{1/2}$. Then

$$ y'=12x^3+2x^{-2}+\frac52x^{-1/2}=12x^3+\frac2{x^2}+\frac5{2\sqrt x}. $$

The exponent decreases by one; the coefficient is multiplied by the old exponent.
### Common mistake
The derivative of $x^{-1}$ is $-x^{-2}$, not $x^0$. The derivative of a constant is zero, whereas the derivative of $cx$ is $c$.
### Self-check
Differentiate $4/x^3-7x+9$ for $x\ne0$.
:::answer
Write $4x^{-3}-7x+9$. The derivative is $-12x^{-4}-7=-12/x^4-7$.
:::
## Product and quotient rules
@source S4 Ch 5A §5.2, PDF pp. 2–15.
### A product changes in both factors

$$ (uv)'=u'v+uv',\qquad \left(\frac uv\right)'=\frac{u'v-uv'}{v^2}\quad(v\ne0). $$

The product rule follows by adding and subtracting $u(x+h)v(x)$ inside the difference quotient. This separates the change in each factor. It is not generally $u'v'$.
### Worked example — product
For $y=(x^2+1)(x^3-2)$,

$$ y'=2x(x^3-2)+(x^2+1)3x^2=5x^4+3x^2-4x. $$

Expanding first gives the same result and provides a check.
### Worked example — quotient
For $y=(x+1)/(x-1)$, $x\ne1$,

$$ y'=\frac{(x-1)-(x+1)}{(x-1)^2}=\frac{-2}{(x-1)^2}. $$

An alternative is $y=1+2/(x-1)$, followed by the chain rule.
### Self-check
Differentiate $x/(x^2+1)$.
:::answer
$y'=[(x^2+1)-x(2x)]/(x^2+1)^2=(1-x^2)/(x^2+1)^2$. The denominator never vanishes for real $x$.
:::
## Composite functions and the chain rule
@source S4 Ch 5A §5.3, PDF pp. 16–23.
### Identify the inner function first
If $y=f(u)$ and $u=g(x)$, then

$$ \frac{dy}{dx}=\frac{dy}{du}\frac{du}{dx}=f'(g(x))g'(x). $$

Differentiate the outer function while keeping its argument, then multiply by the derivative of that argument. With several layers, repeat this process from outside to inside.
### Worked example — a power of a quadratic
For $y=(3x^2-1)^5$, the outer power contributes $5(3x^2-1)^4$ and the inner derivative contributes $6x$. Thus $y'=30x(3x^2-1)^4$.
### Worked example — nested operations
For $y=\sqrt{1+x^{-2}}$, $x\ne0$,

$$ y'=\frac12(1+x^{-2})^{-1/2}(-2x^{-3})=-\frac1{x^3\sqrt{1+x^{-2}}}. $$

The square-root argument is positive on this domain.
### Common mistake
$[(ax+b)^n]'=n(ax+b)^{n-1}a$. Omitting the final $a$ is a chain-rule error, even though the outer derivative looks correct.
### Self-check
Differentiate $(2-5x)^7$.
:::answer
$7(2-5x)^6(-5)=-35(2-5x)^6$.
:::
## Trigonometric derivatives in radians
@source S4 Ch 5B §5.4, PDF pp. 1–9. The source labels sec/csc/cot derivatives as additional formulas outside its core syllabus.
### Core formulas and their origin
In radian measure,

$$ (\sin x)'=\cos x,\qquad (\cos x)'=-\sin x,\qquad (\tan x)'=\sec^2x. $$

For example, expand $\sin(x+h)$ in the difference quotient. The limits $\sin h/h\to1$ and $(\cos h-1)/h\to0$ leave $\cos x$.
### Worked example — product and chain rules
For $y=x\sin(2x)$,

$$ y'=\sin2x+2x\cos2x. $$

The first term comes from differentiating $x$; the factor $2$ in the second term comes from differentiating the inner angle.
### Extension formulas in the supplied notes
Where defined,

$$ (\sec x)'=\sec x\tan x,\quad (\csc x)'=-\csc x\cot x,\quad (\cot x)'=-\csc^2x. $$

These follow from reciprocal or quotient rules. They are retained here as labelled extensions rather than presented as an additional core memorisation requirement.
### Self-check
Differentiate $\cos^2(3x)$.
:::answer
$2\cos3x(-\sin3x)(3)=-6\sin3x\cos3x=-3\sin6x$. Angles must be in radians.
:::
## Exponential and logarithmic derivatives
@source S4 Ch 5B §5.5, PDF pp. 10–15.
### Derivative formulas
For $a>0$,

$$ (e^x)'=e^x,\qquad (a^x)'=a^x\ln a,\qquad (\ln x)'=\frac1x\quad(x>0). $$

For differentiable $u$,

$$ (e^u)'=e^u u',\qquad (\ln|u|)'=\frac{u'}u\quad(u\ne0). $$

The absolute-value form covers negative values of $u$ on intervals that do not cross a zero. It does not define $\ln u$ at negative $u$.
### Worked example
For $y=e^{x^2}\ln x$, $x>0$, apply product and chain rules:

$$ y'=2xe^{x^2}\ln x+\frac{e^{x^2}}x=e^{x^2}\left(2x\ln x+\frac1x\right). $$

For $z=\ln(3x^2+1)$, the derivative is $6x/(3x^2+1)$; its argument is always positive.
### Common mistake
$(\ln x)'$ is $1/x$, whereas $(\log_a x)'=1/(x\ln a)$ for $a>0$, $a\ne1$. Check the base.
### Self-check
Differentiate $2^{3x}$.
:::answer
$3(\ln2)2^{3x}$. There are two factors to retain: the logarithm of the base and the inner derivative.
:::
## Implicit and logarithmic differentiation
@source S4 Ch 5B §5.6, PDF pp. 16–23.
### Treat y as a function of x
When an equation links $x$ and $y$ without isolating $y$, differentiate both sides with respect to $x$. Every derivative of an expression in $y$ needs a factor $y'$ from the chain rule.
### Worked example — an implicit curve
For $x^2+xy+y^2=7$,

$$ 2x+(xy'+y)+2yy'=0,\qquad y'=-\frac{2x+y}{x+2y}, $$

provided $x+2y\ne0$. At $(1,2)$, which lies on the curve, $y'=-4/5$.
### Worked example — variable base and exponent
For $y=x^x$, take $x>0$ so logarithms are defined. Then $\ln y=x\ln x$. Differentiating gives $y'/y=\ln x+1$, hence

$$ y'=x^x(\ln x+1). $$

Neither the fixed-power rule nor the fixed-base exponential rule applies on its own.
### Common mistake
$(xy)'=xy'+y$, not $xy'$. Also, division by the coefficient of $y'$ may exclude points where a separate tangent analysis is needed.
### Self-check
For $x^2+y^2=25$, find $y'$ where $y\ne0$.
:::answer
$2x+2yy'=0$, so $y'=-x/y$.
:::
## Second derivatives and checking a result
@source S4 Ch 5B §5.7, PDF pp. 24–30.
### Differentiate the derivative
The second derivative measures the rate of change of the first derivative:

$$ y''=\frac{d}{dx}\left(\frac{dy}{dx}\right)=\frac{d^2y}{dx^2}. $$

It is not $(y')^2$. A second differentiation may again require product, quotient or chain rules.
### Worked example
For $y=xe^{2x}$,

$$ y'=e^{2x}+2xe^{2x}=e^{2x}(1+2x), $$

$$ y''=2e^{2x}(1+2x)+2e^{2x}=4e^{2x}(x+1). $$

At $x=0$, the first derivative is $1$ and the second derivative is $4$. These describe different aspects of the curve.
### Verification strategy
Simplify before a second derivative when it reduces work. Check dimensions in a physical model: position, velocity and acceleration have different units. For an algebraic result, differentiating an equivalent expanded form can catch missing terms.
### Self-check
Find the first two derivatives of $y=\ln x$ on $x>0$.
:::answer
$y'=1/x$ and $y''=-1/x^2$. Squaring the first derivative would incorrectly give a positive result.
:::
# 7
## Tangents and normals at a known point
@source S4 Ch 6A §6.1, PDF pp. 1–9.
### Point-slope equations
At a point $(a,f(a))$ with finite derivative $m=f'(a)$, the tangent is

$$ y-f(a)=m(x-a). $$

If $m\ne0$, the normal has gradient $-1/m$. If $m=0$, the tangent is horizontal and the normal is the vertical line $x=a$.
### Worked example
For $y=x^2+1$ at $x=2$, the point is $(2,5)$ and $y'=2x$ gives $m=4$. The tangent is $y-5=4(x-2)$, or $y=4x-3$. The normal is $y-5=-\tfrac14(x-2)$.
### Why the perpendicular gradient is a negative reciprocal
Direction vectors $(1,m)$ and $(1,n)$ are perpendicular when their dot product $1+mn=0$, hence $n=-1/m$ when both slopes are finite.
### Self-check
Find the normal to $y=x^2$ at its vertex.
:::answer
At $(0,0)$ the derivative is zero. The tangent is $y=0$ and the normal is $x=0$. Do not try to divide by zero to obtain a normal gradient.
:::
## Tangents with an unknown contact point
@source S4 Ch 6A §6.1, PDF pp. 1–9: tangent question types.
### Parameterise the point of contact
If the contact point is unknown, call its $x$-coordinate $a$, write the tangent at $(a,f(a))$, and impose the additional condition. A point through which the tangent passes need not lie on the curve.
### Worked example — tangents from an external point
Find tangents to $y=x^2$ through $(0,-1)$.

1. At $(a,a^2)$ the gradient is $2a$.
2. The tangent equation is $y-a^2=2a(x-a)$, or $y=2ax-a^2$.
3. Substituting $(0,-1)$ gives $-1=-a^2$, so $a=\pm1$.
4. The two tangents are $y=2x-1$ and $y=-2x-1$.
5. Each line passes through $(0,-1)$ and meets the parabola in a repeated root.
### Other triggers
For a tangent parallel to $y=mx+c$, solve $f'(a)=m$. For a prescribed normal slope $n\ne0$, solve $f'(a)=-1/n$. Always return the contact coordinates as well as the gradient if requested.
### Self-check
Where is the tangent to $y=x^2$ parallel to $y=6x+2$?
:::answer
$2a=6$ gives $a=3$. The contact point is $(3,9)$ and the tangent is $y=6x-9$.
:::
## Increasing intervals and the first derivative test
@source S4 Ch 6A §6.2, PDF pp. 10–20.
### Use signs on intervals
On a differentiable interval, $f'>0$ implies $f$ is increasing and $f'<0$ implies it is decreasing. A stationary point satisfies $f'=0$. Its nature depends on the sign change, not merely the zero derivative.

A $+\to-$ change gives a local maximum; a $-\to+$ change gives a local minimum. No sign change means a stationary point that is neither.
### Worked example
Let $f(x)=x^3-3x$. Then $f'(x)=3(x-1)(x+1)$. The signs on $(-\infty,-1)$, $(-1,1)$ and $(1,\infty)$ are respectively $+,-,+$.

Thus $(-1,2)$ is a local maximum, $(1,-2)$ is a local minimum, and the curve increases outside $[-1,1]$ and decreases between the stationary points.
### Common mistake
A stationary point is not necessarily an extremum: $x^3$ has $f'(0)=0$ but is increasing on both sides. Domain endpoints can be absolute extrema without satisfying $f'=0$.
### Self-check
Classify the stationary point of $f(x)=x^4$ at zero using signs.
:::answer
$f'=4x^3$ changes from negative to positive, so $(0,0)$ is a local minimum.
:::
## Second derivative tests, concavity and inflection
@source S4 Ch 6A §6.3, PDF pp. 21–25. Concavity wording is corrected mathematically in this summary.
### A fast local test
If $f'(a)=0$, then $f''(a)>0$ gives a local minimum and $f''(a)<0$ gives a local maximum, under the usual second-derivative-test hypotheses. If $f''(a)=0$, the test is inconclusive; use sign analysis.
### Concavity
$f''>0$ means the tangent slope is increasing: the graph is concave upwards. $f''<0$ means the slope is decreasing: the graph is concave downwards. An inflection point requires a change in concavity, with the point on the curve.
### Worked example
For $f(x)=x^3-3x$, $f''(x)=6x$. At $x=-1$, $f''=-6<0$, confirming a local maximum. At $x=1$, $f''=6>0$, confirming a local minimum. Concavity changes from down to up at $x=0$, so $(0,0)$ is an inflection point even though $f'(0)=-3\ne0$.
### Common mistake
$f''=0$ is a candidate condition, not proof of inflection. For $x^4$, $f''=12x^2$ stays non-negative and there is no concavity change at zero.
### Self-check
What does the second derivative test say about $f(x)=x^4$ at zero?
:::answer
It is inconclusive because $f''(0)=0$. The first derivative sign test still establishes a minimum.
:::
## Curve sketching: domain, asymptotes and shape
@source S4 Ch 6A §6.4, PDF pp. 26–47.
### A systematic sketch
Determine the domain, intercepts and symmetry first. Find vertical asymptotes from one-sided unbounded behaviour, then horizontal or oblique asymptotes from limits. Use $f'$ for turning behaviour and $f''$ for concavity. Label coordinates and excluded points.
### Worked example — a rational curve
For $f(x)=x+1/x$, the domain excludes zero and $f$ is odd. It has no real $x$-intercept. As $x\to0^+$, $f\to\infty$; as $x\to0^-$, $f\to-\infty$, giving the vertical asymptote $x=0$. Since $f(x)-x=1/x\to0$, the oblique asymptote is $y=x$.

$$ f'(x)=1-\frac1{x^2},\qquad f''(x)=\frac2{x^3}. $$

The stationary points are $(-1,-2)$, a local maximum, and $(1,2)$, a local minimum. The negative branch is concave down and the positive branch concave up.
### Common mistake
A zero denominator may produce a removable hole rather than an asymptote if a common factor cancels. Also, $x=0$ here is not an inflection point: it is outside the domain.
### Self-check
Does a graph necessarily never cross a horizontal asymptote?
:::answer
No. An asymptote describes limiting behaviour, not a forbidden line. A curve can cross it at finite points.
:::
## Rates of change, related rates and motion
@source S4 Ch 6B §6.5, PDF pp. 1–15.
### Connect variables through time
If $V$ depends on $r$ and $r$ depends on time $t$, then $dV/dt=(dV/dr)(dr/dt)$. Derive the relationship before inserting instantaneous values.
### Worked example — a growing sphere
For $V=4\pi r^3/3$,

$$ \frac{dV}{dt}=4\pi r^2\frac{dr}{dt}. $$

If $dV/dt=12$ cm³/s and $r=2$ cm, then $dr/dt=12/(16\pi)=3/(4\pi)$ cm/s. The units distinguish volume growth from radius growth.
### Motion definitions
For displacement $s(t)$, velocity is $v=ds/dt$, speed is $|v|$, and acceleration is $a=dv/dt$. Average velocity is $\Delta s/\Delta t$; average acceleration is $\Delta v/\Delta t$.

For $s=t^3-6t^2+9t$, $v=3(t-1)(t-3)$ and $a=6t-12$. On $1<t<2$, velocity and acceleration are both negative, so speed is increasing despite the negative velocity.
### Self-check
When is a moving particle speeding up?
:::answer
Where $v$ and $a$ have the same sign (equivalently $va>0$ away from rest). Opposite signs indicate decreasing speed.
:::
## Optimisation with constraints and endpoints
@source S4 Ch 6B §6.5, PDF pp. 1–15.
### Translate geometry into one variable
State the quantity to optimise, the constraint, and the feasible domain. Differentiate the resulting single-variable function. Compare all relevant stationary points and endpoints, or justify a unique global optimum using signs.
### Worked example — maximum rectangular area
A rectangle has perimeter $40$ cm. Let one side be $x$, so the other is $20-x$ and $0<x<20$. The area is

$$ A(x)=x(20-x)=20x-x^2. $$

$A'=20-2x=0$ gives $x=10$. Since $A''=-2<0$ and the quadratic is concave down throughout, this is the global maximum. The rectangle is a square with area $100$ cm². Degenerate endpoint shapes have area zero if included in the closure.
### Common mistake
A stationary value outside the feasible domain is not a solution to the physical problem. A local test alone may not settle a global comparison when there are multiple candidates.
### Self-check
A box has a volume formula $V(x)$ valid only for $0<x<3$. May a stationary value at $x=4$ be used?
:::answer
No. It lies outside the feasible domain. Geometry and positivity restrictions must be applied before choosing an answer.
:::
# 8
## Antiderivatives and the constant of integration
@source S5 Ch 7 §7.1–7.2, PDF pp. 1–5.
### Definition
A function $F$ is an antiderivative of $f$ on an interval if $F'=f$ there. The indefinite integral describes the family

$$ \int f(x)\,dx=F(x)+C. $$

Differentiation removes additive constants, so recovering a function requires a constant. Different connected intervals may have different constants. The symbol $dx$ identifies the integration variable.
### Basic rules
For $n\ne-1$,

$$ \int x^n\,dx=\frac{x^{n+1}}{n+1}+C,\qquad \int[af(x)+bg(x)]\,dx=a\int f(x)\,dx+b\int g(x)\,dx. $$

### Worked example
For $x>0$,

$$ \int(3x^2-4x^{-2}+2x^{1/2})\,dx=x^3+4x^{-1}+\frac43x^{3/2}+C. $$

Differentiate each term to check: the result is $3x^2-4x^{-2}+2\sqrt x$, exactly the integrand.
### Common mistake
Increase the exponent first, then divide by the new exponent. The case $n=-1$ is excluded because it would require division by zero.
### Self-check
Find $\int6x^5\,dx$ and verify it.
:::answer
$x^6+C$. Differentiating gives $6x^5$.
:::
## Logarithmic and exponential integrals
@source S5 Ch 7 §7.3, PDF pp. 6–8.
### Reverse familiar derivative rules

$$ \int\frac1x\,dx=\ln|x|+C\quad(x\ne0),\qquad \int e^x\,dx=e^x+C. $$

For $a>0$, $a\ne1$,

$$ \int a^x\,dx=\frac{a^x}{\ln a}+C. $$

For a non-zero constant $k$, a linear inner function produces a reciprocal factor:

$$ \int e^{kx+b}\,dx=\frac1k e^{kx+b}+C,\quad \int\frac1{kx+b}\,dx=\frac1k\ln|kx+b|+C. $$

### Worked example

$$ \int\left(4e^{2x}-\frac3{2x-1}\right)dx=2e^{2x}-\frac32\ln|2x-1|+C. $$

Differentiation returns $4e^{2x}-3/(2x-1)$. The expression is valid separately on intervals avoiding $x=1/2$.
### Common mistake
Integration does not distribute through a product or quotient. In particular, $\int f/g$ is not the quotient of the two integrals.
### Self-check
Find $\int3^{2x}\,dx$.
:::answer
$3^{2x}/(2\ln3)+C$. Differentiating the answer recovers both the base factor $\ln3$ and the inner factor $2$.
:::
## Basic trigonometric integrals and reverse chain rules
@source S5 Ch 7: “Indefinite Integration of Trigonometric Functions”, PDF pp. 20–24; the source repeats the section number 7.4.
### Core integral pairs
For non-zero constant $k$,

$$ \int\cos(kx+b)\,dx=\frac1k\sin(kx+b)+C, $$

$$ \int\sin(kx+b)\,dx=-\frac1k\cos(kx+b)+C,\qquad \int\sec^2(kx+b)\,dx=\frac1k\tan(kx+b)+C. $$

Angles are measured in radians, and intervals must avoid undefined points.
### Worked example

$$ \int[3\cos2x-4\sin(3x)]\,dx=\frac32\sin2x+\frac43\cos3x+C. $$

The positive sign of the cosine term follows from two negatives: the coefficient $-4$ and the integral of sine.
### Recognise a derivative factor
For example, $\int2x\cos(x^2)\,dx=\sin(x^2)+C$, because differentiating the answer produces the inner derivative $2x$.
### Source extensions
The supplied notes also list integrals paired with derivatives of $\sec,\csc,\cot$. Those can be derived by reversing the labelled extension rules in Chapter 6; they should not be confused with the core sine/cosine/tangent pairs.
### Self-check
Find $\int\sec^2(5x-1)\,dx$.
:::answer
$\tfrac15\tan(5x-1)+C$. Forgetting $1/5$ would make the derivative five times too large.
:::
## Initial conditions, curve recovery and motion
@source S5 Ch 7 §7.7, PDF pp. 43–47.
### Recover the constant from data
An integral gives a family of functions. A point on a curve or an initial value determines a member of that family. Integrating a second derivative introduces two independent constants, so two appropriate conditions are needed.
### Worked example — recover a curve
Suppose $y''=6x$, $y'(0)=2$ and $y(1)=5$.

1. Integrate once: $y'=3x^2+C_1$.
2. Apply $y'(0)=2$: $C_1=2$.
3. Integrate again: $y=x^3+2x+C_2$.
4. Apply $y(1)=5$: $1+2+C_2=5$, so $C_2=2$.
5. The curve is $y=x^3+2x+2$. Both supplied conditions check directly.
### Motion application
If acceleration is $a(t)=4$ and $v(0)=-3$, then $v(t)=4t-3$. If additionally $s(0)=2$, displacement is $s(t)=2t^2-3t+2$. The velocity and displacement constants come from different initial conditions.
### Self-check
Does $y'(0)=2$ determine a unique curve when $y''=6x$?
:::answer
No. It fixes $C_1$, but the vertical shift $C_2$ remains arbitrary until a position condition is supplied.
:::
# 9
## Substitution: choosing and changing the variable
@source S5 Ch 7 §7.4 “Integration by Substitution”, PDF pp. 9–19.
### Reverse the chain rule systematically
Choose $u=g(x)$ when the integrand contains a composite function together with a factor proportional to $g'(x)$. Since $du=g'(x)\,dx$,

$$ \int f(g(x))g'(x)\,dx=\int f(u)\,du. $$

Rewrite the entire integrand in the new variable; do not leave unmatched $x$ terms behind. Return to $x$ for an indefinite integral whose question uses $x$.
### Worked example
Evaluate $\int x(1+x^2)^4\,dx$.

1. Put $u=1+x^2$, so $du=2x\,dx$ and $x\,dx=du/2$.
2. The integral becomes $\tfrac12\int u^4\,du=u^5/10+C$.
3. Substitute back: $(1+x^2)^5/10+C$.
4. Differentiate: $(5/10)(1+x^2)^4(2x)=x(1+x^2)^4$.
### Common mistake
Replacing the composite expression while leaving $dx$ unchanged misses the differential factor. Substitution is a change of both expression and variable.
### Self-check
Find $\int 3x^2e^{x^3}\,dx$.
:::answer
With $u=x^3$, $du=3x^2dx$. The answer is $e^{x^3}+C$.
:::
## Logarithmic patterns and algebraic preparation
@source S5 Ch 7 §7.3–7.4, PDF pp. 6–19.
### Recognise a numerator derivative
Where $g(x)\ne0$,

$$ \int\frac{g'(x)}{g(x)}\,dx=\ln|g(x)|+C. $$

If the numerator is not proportional to $g'$, simplify or split it first. Sometimes polynomial division is the most useful preparation.
### Worked example — match and split

$$ \int\frac{x+1}{x^2+1}\,dx=\frac12\int\frac{2x}{x^2+1}\,dx+\int\frac1{x^2+1}\,dx. $$

The first integral is $\tfrac12\ln(x^2+1)$. The second needs a different substitution or the inverse-tangent extension on the trigonometric-substitution page. The whole integral is not simply $\ln(x^2+1)$.
### Worked example — divide first
For $x\ne-1$,

$$ \frac{x^2+1}{x+1}=x-1+\frac2{x+1}, $$

so its integral is $x^2/2-x+2\ln|x+1|+C$. Multiplying the decomposition by $x+1$ verifies it before integrating.
### Self-check
Find $\int(6x-2)/(3x^2-2x+5)\,dx$.
:::answer
$\ln(3x^2-2x+5)+C$. The denominator is positive for every real $x$, and its derivative is exactly the numerator.
:::
## Integrating powers and products of sine and cosine
@source S5 Ch 7 §7.5, PDF pp. 25–37.
### Choose the identity to match parity
For $\int\sin^m x\cos^n x\,dx$ with non-negative integer powers: if the sine power is odd, save one $\sin x$ and use $u=\cos x$; if the cosine power is odd, save one $\cos x$ and use $u=\sin x$. If both powers are even, use double-angle power reduction.
### Worked example — odd sine power

$$ \begin{aligned}\int\sin^3x\cos^2x\,dx&=\int(1-\cos^2x)\cos^2x\sin x\,dx\\&=-\int(u^2-u^4)\,du\\&=-\frac{\cos^3x}{3}+\frac{\cos^5x}{5}+C.\end{aligned} $$

Here $u=\cos x$ and $du=-\sin x\,dx$.
### Worked example — both even
$\sin^2x\cos^2x=\tfrac14\sin^22x=\tfrac18(1-\cos4x)$. Thus its integral is $x/8-\sin4x/32+C$.
### Mixed frequencies
Use product-to-sum for $\sin ax\cos bx$ or similar products. For instance, $\sin3x\cos x=\tfrac12(\sin4x+\sin2x)$.
### Self-check
Find $\int\sin x\cos^4x\,dx$.
:::answer
$-\cos^5x/5+C$, using $u=\cos x$. The minus sign comes from $du=-\sin x\,dx$.
:::
## Trigonometric substitutions and principal intervals
@source S5 Ch 7 §7.5, PDF pp. 25–37: trigonometric-substitution examples and associated extension results.
### Let the radical suggest a substitution
For $a>0$, $x=a\sin\theta$ can simplify $\sqrt{a^2-x^2}$. Choose $-\pi/2\le\theta\le\pi/2$ so $\cos\theta\ge0$ and the radical becomes $a\cos\theta$. For $a^2+x^2$, $x=a\tan\theta$ with $-\pi/2<\theta<\pi/2$ uses $1+\tan^2\theta=\sec^2\theta$.
### Worked example — a supplied-note extension
Evaluate $\int dx/(a^2+x^2)$. Put $x=a\tan\theta$, so $dx=a\sec^2\theta\,d\theta$. Then

$$ \int\frac{dx}{a^2+x^2}=\frac1a\int d\theta=\frac1a\tan^{-1}(x/a)+C. $$

Here $\tan^{-1}$ means inverse tangent, not the reciprocal $\cot$. This inverse-trigonometric antiderivative is retained as an extension appearing through the supplied notes’ substitution methods.
### Why the interval matters
Without controlling the sign, $\sqrt{a^2\cos^2\theta}=a|\cos\theta|$, not automatically $a\cos\theta$.
### Self-check
Which substitution simplifies $\sqrt{9-x^2}$ and what is its real domain?
:::answer
Use $x=3\sin\theta$ with $\theta\in[-\pi/2,\pi/2]$. The radical is real for $-3\le x\le3$ and becomes $3\cos\theta$.
:::
## Integration by parts: derivation and choice of factors
@source S5 Ch 7 §7.6, PDF pp. 38–42.
### Reverse the product rule
Since $(uv)'=u'v+uv'$, integrating and rearranging gives

$$ \int u\,dv=uv-\int v\,du. $$

Choose $dv$ that you can integrate, and $u$ that becomes simpler when differentiated. The remaining integral should be easier than the original.
### Worked example — polynomial times exponential
For $\int xe^{2x}\,dx$, choose $u=x$, $dv=e^{2x}dx$. Then $du=dx$, $v=e^{2x}/2$, so

$$ \int xe^{2x}\,dx=\frac{x e^{2x}}2-\frac12\int e^{2x}dx=\frac{x e^{2x}}2-\frac{e^{2x}}4+C. $$

Differentiation cancels the extra exponential terms, leaving $xe^{2x}$.
### Worked example — a lone logarithm
Write $\int\ln x\,dx=\int(\ln x)\cdot1\,dx$ on $x>0$. Taking $u=\ln x$, $dv=dx$ gives $x\ln x-\int1\,dx=x\ln x-x+C$.
### Self-check
Find $\int x\cos x\,dx$.
:::answer
Choose $u=x$, $dv=\cos xdx$. The result is $x\sin x+\cos x+C$.
:::
## Repeated parts and choosing an integration method
@source S5 Ch 7 §7.4–7.6, PDF pp. 9–42.
### Choose the method from the structure
Simplify sums and rational expressions first. Look for a reverse-chain pair next. Trigonometric identities handle powers or mixed frequencies. Use parts when a product becomes easier after differentiating one factor. A method name alone does not determine whether the remaining integral is manageable.
### Worked example — two rounds of parts
Let $I=\int x^2e^x\,dx$. With $u=x^2$, $dv=e^xdx$,

$$ I=x^2e^x-2\int xe^x\,dx. $$

A second use gives $\int xe^xdx=xe^x-e^x+C$. Therefore

$$ I=e^x(x^2-2x+2)+C. $$

Differentiate: $e^x(x^2-2x+2)+e^x(2x-2)=x^2e^x$. Only one final arbitrary constant is needed.
### Common mistake
Substitution $u=x^2$ in $\int x^2e^x dx$ leaves incompatible factors, so it does not simplify this problem. By contrast, $\int2xe^{x^2}dx$ is an immediate substitution problem.
### Self-check
Choose methods for $\int2x\ln(x^2+1)dx$ and $\int x\ln xdx$.
:::answer
For the first, substitute $u=x^2+1$ and then integrate $\ln u$ by parts. For the second, use parts directly with $u=\ln x$ and $dv=x\,dx$.
:::
# 10
## Definite integrals as limits of sums
@source S5 Ch 8 §8.1, PDF pp. 1–8.

:::diagram riemann
:::

### Accumulation over an interval
For a continuous function on $[a,b]$, partition the interval into $n$ equal widths $\Delta x=(b-a)/n$. Using right endpoints $x_r=a+r\Delta x$,

$$ \int_a^bf(x)\,dx=\lim_{n\to\infty}\sum_{r=1}^nf(x_r)\Delta x. $$

Each term is a signed rectangle contribution. The integral is a number, not a family of functions, so there is no arbitrary $+C$ in its final value.
### Worked example — the area under a square
For $f(x)=x^2$ on $[0,1]$, $\Delta x=1/n$ and $x_r=r/n$:

$$ \sum_{r=1}^n\left(\frac rn\right)^2\frac1n=\frac{n(n+1)(2n+1)}{6n^3}\longrightarrow\frac13. $$

The sum-of-squares formula connects induction and integration.
### Common mistake
The rectangle height is not the whole term: multiply by the width $\Delta x$. A finite rectangle sum is generally an approximation; the limit gives the integral.
### Self-check
For $[2,5]$ with $n$ equal subintervals, write $\Delta x$ and the right endpoint $x_r$.
:::answer
$\Delta x=3/n$, $x_r=2+3r/n$, for $r=1,\ldots,n$.
:::
## The fundamental theorem and integral properties
@source S5 Ch 8 §8.1, PDF pp. 1–8.
### Evaluation by an antiderivative
If $f$ is continuous on $[a,b]$ and $F'=f$, then

$$ \int_a^bf(x)\,dx=F(b)-F(a)=[F(x)]_a^b. $$

The constants cancel between the endpoints. The integration variable is a dummy variable: $\int_a^bf(t)dt$ is the same number.
### Core properties

$$ \int_a^af=0,\quad \int_b^af=-\int_a^bf,\quad \int_a^cf+\int_c^bf=\int_a^bf. $$

Linearity also holds. If $f\ge0$ on $[a,b]$ with $a<b$, its integral is non-negative. Below-axis contributions are negative.
### Worked example

$$ \int_{-1}^2(3x^2-2)dx=[x^3-2x]_{-1}^2=(8-4)-(-1+2)=3. $$

The brackets around the entire lower-endpoint value prevent a common sign error.
### Self-check
If $\int_1^4f=7$ and $\int_1^2f=3$, find $\int_4^2f$.
:::answer
$\int_2^4f=7-3=4$, so reversing the limits gives $\int_4^2f=-4$.
:::
## Definite substitution: transform the bounds
@source S5 Ch 8 §8.2, PDF pp. 9–26.
### Bounds belong to the integration variable
Under $u=g(x)$, the bounds become $u=g(a)$ and $u=g(b)$:

$$ \int_a^bf(g(x))g'(x)dx=\int_{g(a)}^{g(b)}f(u)du. $$

Once the integrand and bounds use $u$, there is no need to substitute back. Alternatively, obtain an antiderivative in $x$ and apply the original bounds; never mix these two approaches.
### Worked example
Evaluate $\int_0^1 2x\sqrt{1+x^2}\,dx$.

1. Set $u=1+x^2$, $du=2xdx$.
2. At $x=0$, $u=1$; at $x=1$, $u=2$.
3. The integral is $\int_1^2u^{1/2}du=[2u^{3/2}/3]_1^2=\tfrac23(2\sqrt2-1)$.
### Reversed substitution limits
For $u=\cos x$ on $[0,\pi/2]$, the new limits are $1$ to $0$ and $du=-\sin xdx$. Reversing those limits removes the minus sign.
### Self-check
Evaluate $\int_0^{\pi/2}\sin x\cos^2x\,dx$.
:::answer
With $u=\cos x$, it is $-\int_1^0u^2du=\int_0^1u^2du=1/3$.
:::
## Definite integration by parts
@source S5 Ch 8 §8.3, PDF pp. 27–33.
### Include the boundary term
The definite form of parts is

$$ \int_a^bu(x)v'(x)dx=[u(x)v(x)]_a^b-\int_a^bu'(x)v(x)dx. $$

The first term is evaluated at both endpoints. It does not remain as an unevaluated function. Check the chosen functions are defined throughout the interval.
### Worked example
Evaluate $\int_0^1xe^x dx$. Take $u=x$, $v'=e^x$, so $u'=1$, $v=e^x$:

$$ \int_0^1xe^xdx=[xe^x]_0^1-\int_0^1e^xdx=e-(e-1)=1. $$

The answer is positive, consistent with a non-negative integrand. Using the antiderivative $(x-1)e^x$ and the original bounds yields the same value.
### Worked example — a logarithm
On $[1,e]$,

$$ \int_1^e\ln x\,dx=[x\ln x-x]_1^e=0-(-1)=1. $$

Do not use zero as a lower endpoint for this elementary calculation without addressing the logarithm’s undefined value there.
### Self-check
Evaluate $\int_0^\pi x\sin x\,dx$.
:::answer
$[-x\cos x]_0^\pi+\int_0^\pi\cos xdx=\pi+0=\pi$.
:::
## Odd/even symmetry and reflection substitutions
@source S5 Ch 8 §8.2, PDF pp. 9–26; §8.4, PDF pp. 34–39.
### Symmetric intervals
For integrable functions on $[-a,a]$, with $a>0$,

$$ f(-x)=f(x)\Rightarrow\int_{-a}^af(x)dx=2\int_0^af(x)dx, $$

$$ f(-x)=-f(x)\Rightarrow\int_{-a}^af(x)dx=0. $$

For the proof, substitute $u=-x$ in the negative half. Equal reflected contributions add for even functions and cancel for odd functions.
### General reflection identity
Substitute $u=a+b-x$ to obtain

$$ \int_a^bf(x)dx=\int_a^bf(a+b-x)dx. $$

Thus, if $f(x)+f(a+b-x)=K$, the integral equals $K(b-a)/2$.
### Worked example
For $I=\int_0^{\pi/2}\sin x/(\sin x+\cos x)\,dx$, reflection $x\mapsto\pi/2-x$ changes the numerator to $\cos x$ and leaves the denominator unchanged. Adding the two forms gives $2I=\int_0^{\pi/2}1dx=\pi/2$. Therefore $I=\pi/4$.
### Self-check
Evaluate $\int_{-2}^2(x^3+x^2)dx$ using symmetry.
:::answer
The odd part cancels. The result is $2\int_0^2x^2dx=16/3$. A zero signed integral would not imply zero geometric area.
:::
# 11
## Signed integrals and geometric area
@source S5 Ch 9 §9.1, PDF pp. 1–15.
### Area is non-negative
For a continuous graph, the area between $y=f(x)$ and the $x$-axis on $[a,b]$ is

$$ A=\int_a^b|f(x)|dx. $$

Find the zeros first and split wherever the sign changes. A definite integral without the absolute value measures signed accumulation and may cancel.
### Worked example
Find the area between $y=x^2-1$ and the $x$-axis from $x=-2$ to $2$. The zeros are $\pm1$, and symmetry gives

$$ \begin{aligned}A&=2\left[\int_0^1(1-x^2)dx+\int_1^2(x^2-1)dx\right]\\&=2\left[\left(x-\frac{x^3}3\right)_0^1+\left(\frac{x^3}3-x\right)_1^2\right]\\&=2\left(\frac23+\frac43\right)=4.\end{aligned} $$

The unsplit signed integral is $4/3$, so it answers a different question.
### Self-check
A curve has integral $-5$ over an interval and is everywhere below the axis there. What is the area?
:::answer
The area is $5$. If the curve crossed the axis, the integral alone would not determine total area.
:::
## Areas between curves and choosing the slice direction
@source S5 Ch 9 §9.1, PDF pp. 1–15.
### Vertical and horizontal slices
When $f\ge g$ on $[a,b]$, vertical slices give $A=\int_a^b[f(x)-g(x)]dx$. For horizontal slices, subtract left boundary from right boundary and integrate with respect to $y$. Solve intersections to determine bounds; split if the order of the curves changes.
### Worked example
Find the enclosed area between $y=2x$ and $y=x^2$.

1. Intersections satisfy $x^2=2x$, hence $x=0,2$.
2. For $0<x<2$, $2x>x^2$.
3. Therefore $A=\int_0^2(2x-x^2)dx=[x^2-x^3/3]_0^2=4/3$.

Using horizontal slices, $0\le y\le4$ and the right curve is $x=\sqrt y$, the left is $x=y/2$. Thus $A=\int_0^4(\sqrt y-y/2)dy=4/3$ again.
### Common mistake
A bound is a coordinate of the integration variable, not merely a number copied from an intersection. If integrating in $y$, use $y$-coordinates and functions of $y$.
### Self-check
What changes if two curves switch upper/lower position inside the interval?
:::answer
Split at each crossing and apply upper minus lower on each part, or integrate the absolute difference with those sign changes handled explicitly.
:::
## Volumes of revolution: discs and washers
@source S5 Ch 9 §9.2, PDF pp. 16–28.
### Build the solid from circular slices
Rotating around the $x$-axis gives

$$ V=\pi\int_a^b[R(x)^2-r(x)^2]dx, $$

where $R\ge r\ge0$ are actual distances from the axis. A disc is the case $r=0$. Around the $y$-axis, use horizontal slices:

$$ V=\pi\int_c^d[R(y)^2-r(y)^2]dy. $$

The washer area is the difference of two circle areas, not the square of the difference of radii.
### Worked example
Rotate the region between $y=\sqrt x$ and $y=x$ for $0\le x\le1$ about the $x$-axis. Here $R=\sqrt x$, $r=x$, so

$$ V=\pi\int_0^1(x-x^2)dx=\pi\left(\frac12-\frac13\right)=\frac\pi6. $$

For a disc example, rotating the region under $y=\sqrt x$ from $0$ to $4$ gives $V=\pi\int_0^4x dx=8\pi$.
### Self-check
Why is $\pi\int_0^1(\sqrt x-x)^2dx$ incorrect for the washer example?
:::answer
It uses a circle whose radius is the gap between the curves. A washer requires the outer circle area minus the inner circle area: $\pi(R^2-r^2)$.
:::
## Shifted axes, displacement and distance
@source S5 Ch 9 §9.2, PDF pp. 16–28: shifted axes; motion links to S4 Ch 6B §6.5 and S5 Ch 7 §7.7.
### Measure radii from the rotation axis
For rotation about $y=k$, the radius is a vertical distance $|y-k|$. For rotation about $x=h$, it is a horizontal distance $|x-h|$. Draw the cross-section to identify inner and outer radii. Regions crossing the axis require care because their rotated portions may overlap.
### Worked example — a shifted horizontal axis
Rotate the region $0\le x\le1$, $0\le y\le x$ about $y=-1$. Its outer radius is $x+1$ and its inner radius is $1$. Therefore

$$ V=\pi\int_0^1[(x+1)^2-1]dx=\pi\int_0^1(x^2+2x)dx=\frac{4\pi}{3}. $$

### Accumulation in motion
For velocity $v(t)$, displacement change is $\int vdt$, while total distance is $\int|v|dt$. For $v=t-1$ on $[0,2]$, displacement change is zero but distance is $\int_0^1(1-t)dt+\int_1^2(t-1)dt=1$.
### Self-check
What is the distance of the point $(x,y)$ from the horizontal line $y=3$?
:::answer
$|y-3|$. Squaring removes this absolute value in a disc formula, but choosing the outer and inner radii still requires geometric reasoning.
:::
# 12
## Matrices: order, entries and basic operations
@source S5 Ch 10 §10.1, PDF pp. 1–7.
### A structured array
An $m\times n$ matrix has $m$ rows and $n$ columns. Its entry $a_{ij}$ lies in row $i$, column $j$. Two matrices are equal only when their dimensions agree and all corresponding entries agree.

A row matrix has one row; a column matrix has one column. A square matrix has equal row and column counts. A diagonal matrix has zero off-diagonal entries; an identity matrix $I$ has ones on its diagonal; a zero matrix has all entries zero.
### Addition and scalar multiplication
Only matrices of the same order can be added. Add entries in matching positions. A scalar multiplies every entry.
### Worked example
For

$$ A=\begin{pmatrix}1&-2\\3&0\end{pmatrix},\quad B=\begin{pmatrix}2&4\\-1&5\end{pmatrix}, $$

$$ 2A-B=\begin{pmatrix}0&-8\\7&-5\end{pmatrix}. $$

For example, the $(2,1)$ entry is $2(3)-(-1)=7$.
### Self-check
Can a $2\times3$ matrix be added to a $3\times2$ matrix?
:::answer
No. Having the same total number of entries is insufficient; corresponding rows and columns must have the same structure.
:::
## Matrix multiplication and non-commutativity
@source S5 Ch 10 §10.2, PDF pp. 7–13.
### Row by column
If $A$ is $m\times n$ and $B$ is $n\times p$, then $AB$ is $m\times p$, with

$$ (AB)_{ij}=\sum_{r=1}^na_{ir}b_{rj}. $$

The inner dimensions must match. Even when both products exist, $AB$ generally differs from $BA$. Multiplication is associative and distributes over addition, with dimensions respected.
### Worked example
Let

$$ A=\begin{pmatrix}1&2\\0&1\end{pmatrix},\quad B=\begin{pmatrix}2&0\\3&1\end{pmatrix}. $$

Then

$$ AB=\begin{pmatrix}8&2\\3&1\end{pmatrix},\qquad BA=\begin{pmatrix}2&4\\3&7\end{pmatrix}. $$

For instance, $(AB)_{11}=1(2)+2(3)=8$. The unequal results demonstrate why the order must remain fixed.
### Common mistake
Matrix multiplication is not entrywise multiplication. Also, $AB=0$ does not force $A=0$ or $B=0$; non-zero matrices may multiply to a zero matrix.
### Self-check
If $A$ is $2\times3$ and $B$ is $3\times4$, what are the dimensions of $AB$ and does $BA$ exist?
:::answer
$AB$ is $2\times4$. $BA$ is undefined because its inner dimensions would be $4$ and $2$.
:::
## Determinants, minors and cofactors
@source S5 Ch 10 §10.3, PDF pp. 13–20.
### A determinant is a scalar
A determinant is defined for a square matrix. For order two,

$$ \det\begin{pmatrix}a&b\\c&d\end{pmatrix}=ad-bc. $$

For a larger square matrix, the minor $M_{ij}$ is the determinant obtained by deleting row $i$ and column $j$. The cofactor is $C_{ij}=(-1)^{i+j}M_{ij}$. Its checkerboard of signs begins $+,-,+$ in the first row.
### Expansion along a row

$$ \det A=\sum_ja_{ij}C_{ij}. $$

Choose a row or column with many zeros to reduce work. Column expansion uses the same cofactor rule.
### Worked example

$$ \begin{aligned}\det\begin{pmatrix}1&2&0\\0&3&4\\5&0&6\end{pmatrix}&=1\begin{vmatrix}3&4\\0&6\end{vmatrix}-2\begin{vmatrix}0&4\\5&6\end{vmatrix}\\&=18-2(-20)=58.\end{aligned} $$

The minus sign in the second term is the cofactor sign; it is separate from the negative value of the minor.
### Self-check
Find the cofactor $C_{12}$ in the example.
:::answer
The minor is $0(6)-4(5)=-20$. Therefore $C_{12}=(-1)^3(-20)=20$.
:::
## Determinant properties and efficient evaluation
@source S5 Ch 10 §10.3–10.4, PDF pp. 13–36: determinant and inverse properties.
### Track operations precisely
Interchanging two rows reverses the determinant’s sign. Multiplying one row by $k$ multiplies the determinant by $k$. Adding a multiple of another row leaves it unchanged. A triangular matrix has determinant equal to the product of diagonal entries.

For square matrices of the same order $n$,

$$ \det(AB)=\det A\det B,\quad\det(A^T)=\det A,\quad\det(kA)=k^n\det A. $$

A zero row, two proportional rows, or two equal rows forces determinant zero.
### Worked example
For $A=\begin{pmatrix}1&2&3\\2&5&7\\0&1&4\end{pmatrix}$, perform $R_2\leftarrow R_2-2R_1$:

$$ \det A=\det\begin{pmatrix}1&2&3\\0&1&1\\0&1&4\end{pmatrix}. $$

Then $R_3\leftarrow R_3-R_2$ gives diagonal entries $1,1,3$, so $\det A=3$. Both operations preserve the determinant.
### Self-check
For a $3\times3$ matrix with determinant $5$, find $\det(2A)$.
:::answer
$2^3(5)=40$. Scaling the whole matrix scales all three rows, not just one.
:::
## Transpose, adjugate and inverse matrices
@source S5 Ch 10 §10.4, PDF pp. 20–36.
### Reverse multiplication only when justified
The transpose swaps rows and columns: $(A^T)_{ij}=a_{ji}$, and $(AB)^T=B^TA^T$. An inverse satisfies $AA^{-1}=A^{-1}A=I$ and exists precisely when $\det A\ne0$.

For order two,

$$ A^{-1}=\frac1{ad-bc}\begin{pmatrix}d&-b\\-c&a\end{pmatrix}. $$

In general, $\operatorname{adj}A$ is the transpose of the cofactor matrix, and $A^{-1}=\operatorname{adj}A/\det A$ when nonsingular. Also $(AB)^{-1}=B^{-1}A^{-1}$.
### Worked example
For $A=\begin{pmatrix}2&1\\5&3\end{pmatrix}$, $\det A=6-5=1$, so

$$ A^{-1}=\begin{pmatrix}3&-1\\-5&2\end{pmatrix}. $$

Multiplication gives $AA^{-1}=\begin{pmatrix}1&0\\0&1\end{pmatrix}$, verifying the result.
### Common mistake
Taking the reciprocal of every entry does not produce an inverse. For order three, forgetting the transpose of the cofactor matrix produces the wrong adjugate.
### Self-check
If $AB=C$ and $A$ is invertible, how do you isolate $B$?
:::answer
Multiply on the left: $B=A^{-1}C$. Multiplication on the right would not cancel the adjacent $A$.
:::
# 13
## Matrix form, inverse methods and Cramer’s rule
@source S5 Ch 11 §11.1, PDF pp. 1–11.
### Encode the equations
Write a system as $A\mathbf x=\mathbf b$, where rows of $A$ contain equation coefficients in a fixed variable order. For a square nonsingular $A$, the unique solution is $\mathbf x=A^{-1}\mathbf b$.

Cramer’s rule gives $x_i=\det A_i/\det A$, where $A_i$ replaces column $i$ by $\mathbf b$. The denominator must be non-zero.
### Worked example
For $2x+y=5$, $x-y=1$,

$$ A=\begin{pmatrix}2&1\\1&-1\end{pmatrix},\quad \det A=-3. $$

Replacing the first column gives $\det A_1=\begin{vmatrix}5&1\\1&-1\end{vmatrix}=-6$, so $x=2$. Replacing the second gives $\det A_2=\begin{vmatrix}2&5\\1&1\end{vmatrix}=-3$, so $y=1$. Both equations check.
### Common mistake
A determinant zero does not by itself distinguish no solutions from infinitely many. Cramer’s quotient formula cannot be used with denominator zero; analyse consistency by elimination instead.
### Self-check
If a square coefficient matrix has non-zero determinant, how many solutions are there?
:::answer
Exactly one for every right-hand-side vector. The inverse exists and determines it uniquely.
:::
## Gaussian elimination and augmented matrices
@source S5 Ch 11 §11.2, PDF pp. 12–17.
### Preserve the solution set
An augmented matrix $[A\mid\mathbf b]$ keeps coefficients and constants together. Valid elementary row operations are swapping rows, multiplying a row by a non-zero scalar, and adding a multiple of one row to another. Apply the operation to the entire row, including the constant.
### Worked example
Solve $x+y+z=6$, $2x+y-z=1$, $x-y+z=2$.

1. Subtract twice row 1 from row 2: $-y-3z=-11$.
2. Subtract row 1 from row 3: $-2y=-4$.
3. From the third row, $y=2$.
4. Substitute into the second: $-2-3z=-11$, so $z=3$.
5. From row 1, $x=6-2-3=1$.

The solution $(1,2,3)$ satisfies all original equations. A row-echelon arrangement would place the pivot rows in increasing pivot-column order before back substitution.
### Common mistake
Replacing a row by zero times itself destroys information and is not an invertible row operation. With parameters, do not divide by an expression that may be zero without splitting cases.
### Self-check
What does a row $[0\ 0\ 0\mid5]$ mean?
:::answer
It means $0=5$, a contradiction. The original system is inconsistent and has no solution.
:::
## Unique, infinite and inconsistent systems
@source S5 Ch 11 §11.3, PDF pp. 17–22.
### Read pivots and free variables
After elimination, a contradictory row gives no solution. If the system is consistent and every variable is a pivot variable, the solution is unique. A consistent system with a free variable has infinitely many real solutions, expressed using parameters.
### Worked example — classify a parameter
Consider

$$ x+y=2,\qquad 2x+ky=c. $$

Subtract twice the first equation from the second to get $(k-2)y=c-4$.

1. If $k\ne2$, then $y=(c-4)/(k-2)$ and $x=2-y$: a unique solution.
2. If $k=2$ and $c=4$, the second equation repeats the first. Put $y=t$, so $(x,y)=(2-t,t)$ for any real $t$.
3. If $k=2$ and $c\ne4$, the reduced equation is $0=c-4\ne0$: no solution.
### Common mistake
Dividing by $k-2$ before treating $k=2$ would erase the cases the question may be asking about. A zero determinant only flags the need for this extra analysis.
### Self-check
Do three equations in three unknowns always have one solution?
:::answer
No. Equations can be dependent or inconsistent. Count pivots and check consistency rather than relying on the equation count alone.
:::
## Homogeneous systems and non-trivial solutions
@source S5 Ch 11 §11.4, PDF pp. 22–31.
### The zero solution always exists
A homogeneous system is $A\mathbf x=\mathbf0$. It is always consistent because $\mathbf x=\mathbf0$ is a solution, called the trivial solution.

For an $n\times n$ matrix, $\det A\ne0$ gives only the trivial solution. If $\det A=0$, at least one free variable remains, giving infinitely many solutions including non-trivial ones.
### Worked example
For

$$ x+2y-z=0,\qquad 2x+4y-2z=0, $$

the second equation is twice the first. Set $y=s$, $z=t$. Then $x=-2s+t$, so

$$ (x,y,z)=s(-2,1,0)+t(1,0,1),\qquad s,t\in\mathbb R. $$

Choosing $(s,t)=(1,0)$ gives the non-trivial solution $(-2,1,0)$, and direct substitution checks it.
### Parameter questions
For a square system containing a parameter, first solve $\det A=0$ to identify possible non-trivial-solution cases, then eliminate separately for each permitted parameter value to find the full solution set.
### Self-check
Can a homogeneous real linear system have no solutions?
:::answer
No. The zero vector always solves every equation. It may be the only solution.
:::
# 14
## Vectors, magnitude and directed segments
@source S5 Ch 12 §12.1–12.2, PDF pp. 1–9.
### Scalar versus vector
A scalar has magnitude alone; a vector has magnitude and direction. Displacement, velocity and force are vectors. Distance, speed and time are scalars. Equal vectors have equal magnitudes and directions regardless of where their arrows are drawn.

The negative vector $-\mathbf a$ reverses direction without changing magnitude. For a scalar $k$, $k\mathbf a$ has magnitude $|k||\mathbf a|$, with direction reversed if $k<0$. The zero vector has zero magnitude and no unique direction.
### Addition and subtraction
The triangle law is

$$ \overrightarrow{AB}+\overrightarrow{BC}=\overrightarrow{AC}. $$

The parallelogram diagonal gives the sum of two vectors with a common initial point. Subtraction means adding the negative vector.
### Worked example
If $\overrightarrow{AB}=\mathbf p$ and $\overrightarrow{AC}=\mathbf q$, then $\overrightarrow{BC}=\overrightarrow{BA}+\overrightarrow{AC}=-\mathbf p+\mathbf q$.
### Self-check
If $\overrightarrow{AB}=\mathbf a$, express $\overrightarrow{BA}$ and its magnitude.
:::answer
$\overrightarrow{BA}=-\mathbf a$ and $|\overrightarrow{BA}|=|\mathbf a|$. Reversing a vector does not make its length negative.
:::
## Position vectors, internal division and centroids
@source S5 Ch 12 §12.3, PDF pp. 9–13.
### Position depends on a reference origin
If $\overrightarrow{OA}=\mathbf a$ and $\overrightarrow{OB}=\mathbf b$, then

$$ \overrightarrow{AB}=\mathbf b-\mathbf a. $$

For $P$ dividing $AB$ internally in the ratio $AP:PB=m:n$ with $m,n>0$,

$$ \mathbf p=\frac{n\mathbf a+m\mathbf b}{m+n}. $$

Derive it from $\overrightarrow{AP}=\frac{m}{m+n}\overrightarrow{AB}$. The weight on the endpoint $B$ is the fraction travelled from $A$ towards $B$.
### Worked example
For $\mathbf a=(1,2)$, $\mathbf b=(6,7)$ and $AP:PB=2:3$,

$$ \mathbf p=\frac{3(1,2)+2(6,7)}5=(3,4). $$

Then $\overrightarrow{AP}=(2,2)$ and $\overrightarrow{PB}=(3,3)$, confirming the ratio.
### Midpoints and a useful consequence
The midpoint is $(\mathbf a+\mathbf b)/2$. A triangle’s centroid is $(\mathbf a+\mathbf b+\mathbf c)/3$, obtained by dividing a median in ratio $2:1$ from the vertex.
### Self-check
If $AP:PB=1:4$, is $P$ nearer $A$ or $B$?
:::answer
Nearer $A$. Its position is $(4\mathbf a+\mathbf b)/5$, one fifth of the way from $A$ to $B$.
:::
## Coordinates, unit vectors and directions
@source S5 Ch 12 §12.4, PDF pp. 13–20.
### Resolve into perpendicular components
In three dimensions,

$$ \mathbf a=a_1\mathbf i+a_2\mathbf j+a_3\mathbf k,\qquad |\mathbf a|=\sqrt{a_1^2+a_2^2+a_3^2}. $$

For non-zero $\mathbf a$, the unit vector in its direction is $\widehat{\mathbf a}=\mathbf a/|\mathbf a|$. In a plane, a vector of magnitude $r$ making angle $\theta$ with the positive $x$-axis has components $(r\cos\theta,r\sin\theta)$.
### Worked example
Let $A=(2,-1,3)$ and $B=(-2,2,3)$. Then $\overrightarrow{AB}=(-4,3,0)$ and $|AB|=5$. The unit vector from $A$ towards $B$ is $(-4/5,3/5,0)$. Its squared magnitude is $16/25+9/25=1$.
### Common mistake
A point’s coordinates and a displacement vector can share notation but play different roles. Form the displacement by final minus initial coordinates before calculating a length or direction.
### Self-check
Find the vector of length $6$ in the direction of $(1,2,2)$.
:::answer
The given vector has magnitude $3$, so multiply its unit vector by $6$: $6(1,2,2)/3=(2,4,4)$.
:::
## Parallelism, collinearity and vector proofs
@source S5 Ch 12 §12.2–12.4, PDF pp. 2–20.
### A scalar-multiple test
Non-zero vectors $\mathbf u$ and $\mathbf v$ are parallel exactly when $\mathbf u=k\mathbf v$ for some non-zero real $k$. Points $A,B,C$ are collinear when the displacement vectors from a common point are scalar multiples, with coincident points treated separately.
### Worked example
Let $A=(1,2)$, $B=(3,6)$ and $C=(4,8)$. Then $\overrightarrow{AB}=(2,4)$ and $\overrightarrow{AC}=(3,6)=\tfrac32\overrightarrow{AB}$, proving collinearity.
### A vector geometry proof
If $M,N$ are the midpoints of $AB,AC$, then

$$ \overrightarrow{MN}=\frac{\mathbf a+\mathbf c}{2}-\frac{\mathbf a+\mathbf b}{2}=\frac12(\mathbf c-\mathbf b)=\frac12\overrightarrow{BC}. $$

Thus the midpoint segment is parallel to $BC$ and half its length. This proves both statements without measuring a diagram.
### Common mistake
Component ratios are inconvenient when a denominator is zero. A scalar-multiple equation or a determinant/cross-product test avoids division by zero.
### Self-check
Are $(0,2,4)$ and $(0,-3,-6)$ parallel?
:::answer
Yes. The second vector is $-3/2$ times the first. A zero first component causes no difficulty with the scalar-multiple test.
:::
# 15
## Scalar products and angles between vectors
@source S5 Ch 13 §13.1, PDF pp. 1–12.
### Geometric and coordinate definitions
For non-zero vectors with included angle $0\le\theta\le\pi$,

$$ \mathbf a\cdot\mathbf b=|\mathbf a||\mathbf b|\cos\theta=a_1b_1+a_2b_2+a_3b_3. $$

The result is a scalar. The dot product is commutative and distributive, and $\mathbf a\cdot\mathbf a=|\mathbf a|^2$. Non-zero vectors are perpendicular exactly when their dot product is zero.
### Worked example
For $\mathbf a=(1,2,2)$ and $\mathbf b=(2,0,1)$, $\mathbf a\cdot\mathbf b=4$, $|\mathbf a|=3$, and $|\mathbf b|=\sqrt5$. Therefore

$$ \cos\theta=\frac4{3\sqrt5},\qquad \theta=\cos^{-1}\left(\frac4{3\sqrt5}\right). $$

The positive dot product indicates an acute angle, a useful check.
### Common mistake
For the angle $ABC$, use $\overrightarrow{BA}$ and $\overrightarrow{BC}$, both starting at $B$. Reversing only one vector gives the supplementary angle.
### Self-check
Find the angle between $(1,1,0)$ and $(1,-1,0)$.
:::answer
Their dot product is zero and both are non-zero, so the angle is $90^\circ$ or $\pi/2$.
:::
## Projections, signed components and perpendicular feet
@source S5 Ch 13, “Projection of Vectors”, PDF pp. 13–19.

:::diagram projection
:::

### Distinguish three related quantities
For $\mathbf b\ne\mathbf0$, the signed scalar component of $\mathbf a$ along $\mathbf b$ is $(\mathbf a\cdot\mathbf b)/|\mathbf b|$. The projection vector and its length are

$$ \operatorname{proj}_{\mathbf b}\mathbf a=\frac{\mathbf a\cdot\mathbf b}{|\mathbf b|^2}\mathbf b,\qquad \left|\operatorname{proj}_{\mathbf b}\mathbf a\right|=\frac{|\mathbf a\cdot\mathbf b|}{|\mathbf b|}. $$

A negative scalar component means the projection points opposite to $\mathbf b$. The perpendicular residual is $\mathbf a-\operatorname{proj}_{\mathbf b}\mathbf a$ and has zero dot product with $\mathbf b$.
### Worked example
For $\mathbf a=(3,2)$ and $\mathbf b=(4,0)$, the projection is $(12/16)(4,0)=(3,0)$. The residual $(0,2)$ is perpendicular to $\mathbf b$.

For $\mathbf a=(-3,2)$ instead, the signed component is $-3$, the projection vector is $(-3,0)$ and its length is $3$.
### Self-check
How do you find the perpendicular foot from $P$ to a line through $A$ in direction $\mathbf d\ne0$?
:::answer
Its position vector is $\mathbf a+\operatorname{proj}_{\mathbf d}(\mathbf p-\mathbf a)$. Project the displacement from a point on the line, not the position of $P$ alone.
:::
## Vector products, orientation and coordinates
@source S5 Ch 13 §13.3, PDF pp. 20–29.
### Magnitude and direction
The cross product is a vector perpendicular to both input vectors, directed by the right-hand rule:

$$ |\mathbf a\times\mathbf b|=|\mathbf a||\mathbf b|\sin\theta. $$

It is anti-commutative: $\mathbf b\times\mathbf a=-\mathbf a\times\mathbf b$. For non-zero vectors, a zero cross product characterises parallelism. It distributes over addition but is not generally associative.
### Coordinate calculation

$$ \mathbf a\times\mathbf b=\begin{vmatrix}\mathbf i&\mathbf j&\mathbf k\\a_1&a_2&a_3\\b_1&b_2&b_3\end{vmatrix}=(a_2b_3-a_3b_2,\ a_3b_1-a_1b_3,\ a_1b_2-a_2b_1). $$

The middle cofactor has a minus sign.
### Worked example
For $\mathbf a=(1,2,0)$ and $\mathbf b=(0,1,3)$, the product is $(6,-3,1)$. Check perpendicularity: $(6,-3,1)\cdot(1,2,0)=0$ and $(6,-3,1)\cdot(0,1,3)=0$.
### Self-check
What are $\mathbf i\times\mathbf j$ and $\mathbf j\times\mathbf i$?
:::answer
$\mathbf k$ and $-\mathbf k$. Equal magnitudes do not imply equal vectors when directions differ.
:::
## Areas, heights and geometric applications
@source S5 Ch 13 §13.3, PDF pp. 30–35.
### Base times perpendicular height
The cross-product magnitude gives the area of the parallelogram spanned by two vectors. Therefore

$$ A_{\triangle ABC}=\frac12|\overrightarrow{AB}\times\overrightarrow{AC}|. $$

Both vectors must describe adjacent sides from the same vertex. A point-to-line distance follows by dividing the parallelogram area by its base length.
### Worked example — area and height
Let $A=(0,0,0)$, $B=(2,0,0)$ and $C=(1,3,0)$. Then $\overrightarrow{AB}\times\overrightarrow{AC}=(0,0,6)$, so the triangle area is $3$. The perpendicular distance from $C$ to line $AB$ is $6/|AB|=6/2=3$.
### General distance formula
For a line through $A$ with non-zero direction $\mathbf d$,

$$ \operatorname{dist}(P,\text{line})=\frac{|(\mathbf p-\mathbf a)\times\mathbf d|}{|\mathbf d|}. $$

This is the distance to the infinite line; a line segment additionally requires checking whether the perpendicular foot lies between the endpoints.
### Self-check
If the cross product of two non-zero side vectors is zero, what is the triangle’s area?
:::answer
Zero. The vectors are parallel, so the three vertices are collinear and the triangle is degenerate.
:::
## Dot versus cross: a connected formula reference
@source S5 Ch 13 §13.1 and §13.3, PDF pp. 1–35.
### Select by the requested output
Use a dot product for angles, perpendicularity and projection. Use a cross product for orientation, parallelism, perpendicular vectors and areas. A dot product returns a scalar; a cross product returns a vector.
### A bridge between the products
Because $\sin^2\theta+\cos^2\theta=1$,

$$ |\mathbf a\times\mathbf b|^2=|\mathbf a|^2|\mathbf b|^2-(\mathbf a\cdot\mathbf b)^2. $$

Also, expanding a dot product gives

$$ |\mathbf a\pm\mathbf b|^2=|\mathbf a|^2+|\mathbf b|^2\pm2\mathbf a\cdot\mathbf b. $$

### Worked example — area without components
If $|\mathbf a|=3$, $|\mathbf b|=4$ and $\mathbf a\cdot\mathbf b=6$, then $|\mathbf a\times\mathbf b|=\sqrt{9(16)-36}=6\sqrt3$. The triangle spanned by these vectors has area $3\sqrt3$.

The angle check gives $\cos\theta=6/12=1/2$, so $\theta=60^\circ$ and $3(4)\sin60^\circ=6\sqrt3$, agreeing with the identity.
### Self-check
Is $\mathbf a\cdot(\mathbf b\cdot\mathbf c)$ a valid dot-product expression?
:::answer
No. The inner dot product is a scalar, and a dot product requires two vectors. Always check the type of each intermediate result.
:::
