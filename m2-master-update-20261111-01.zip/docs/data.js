/* Original starter content. 15 teaching chapters, not official chapter numbering. */
const C=(title,en,body,formula,example,tip)=>({title,en,body,formula,example,tip});
const M=(title,prompt,options,correct,explanation,difficulty='基礎')=>({kind:'mc',title,prompt,options,correct,explanation,difficulty,marks:1});
const L=(title,prompt,solution,marks=5)=>({kind:'long',title,prompt,solution,difficulty:'進階',marks});
const COURSE=[
{title:'數學歸納法',en:'Mathematical Induction',group:'基礎知識',unit:'官方單元 2',glyph:'∑',desc:'從第一步到任意一步，建立嚴謹的數學證明。',types:['歸納法原理','有限數列求和','歸納證明'],concepts:[
C('數學歸納法','Principle of mathematical induction','先證明起始命題，再證明任意正整數 k 的命題成立時，k+1 的命題也成立。','P(1),\\quad P(k)\\Rightarrow P(k+1)','證明奇數和公式時，先驗證 n=1：1=1²。','只驗證幾個數值，並不等於證明。'),
C('歸納假設','Induction hypothesis','假設 P(k) 對某個任意正整數 k 成立，並在下一步明確引用此假設。','\\sum_{r=1}^{k}r=\\frac{k(k+1)}2','加上 k+1 後，右式化為 (k+1)(k+2)/2。','不要假設 P(k+1) 已經成立。'),
C('有限數列與求和','Finite sums','Σ 記號表示由指定下限至上限的有限項總和。','\\sum_{r=1}^{n}(2r-1)=n^2','1+3+5+7=16=4²。','M2 核心範圍的歸納法側重有限數列求和。')],questions:[
M('歸納步驟','使用數學歸納法證明對所有正整數 n 成立的命題，驗證 P(1) 後，應證明甚麼？',['P(2) 與 P(3) 成立','假設 P(k) 成立，推出 P(k+1) 成立','直接假設所有 P(n) 成立','只證明 P(k+1)'],1,'歸納步驟必須建立任意正整數 k 下的推論 $P(k)\\Rightarrow P(k+1)$，不能只驗證有限個例子。'),
M('下一項的角色','已知 $1+3+\\cdots +(2k-1)=k^2$。加入下一項後的總和是？',['$k^2+2k$','$(k+1)^2$','$k^2+1$','$(k+2)^2$'],1,'下一項為 $2k+1$，所以 $k^2+(2k+1)=(k+1)^2$。','應用'),
L('奇數和的證明','用數學歸納法證明，對所有正整數 $n$，$$1+3+\\cdots +(2n-1)=n^2.$$ 請清楚寫出起始步驟、歸納假設及歸納步驟。','當 $n=1$，左方 $=1=1^2$。假設 $n=k$ 時成立。當 $n=k+1$，左方 $=k^2+(2k+1)=(k+1)^2$，故命題由數學歸納法對所有正整數成立。建議評分：起始步驟 1、假設 1、加入正確下一項 1、化簡 1、結論 1。') ]},
{title:'二項式定理',en:'Binomial Theorem',group:'基礎知識',unit:'官方單元 3',glyph:'ⁿCᵣ',desc:'掌握展開式、通項與指定項的係數。',types:['二項展開','指定項與係數','綜合展開'],concepts:[
C('正整數次方展開','Binomial expansion','n 為正整數時，可利用組合係數展開二項式。','(a+b)^n=\\sum_{r=0}^{n}\\binom nr a^{n-r}b^r','(1+x)³=1+3x+3x²+x³。','通項的編號是 r+1，而不是 r。'),
C('通項','General term','先寫通項，再根據 x 的指數確定 r。','T_{r+1}=\\binom nr a^{n-r}b^r','(1+2x)⁴ 的 x² 項為 C(4,2)(2x)²=24x²。','負號及括號內的常數也要取 r 次方。'),
C('組合數','Binomial coefficient','組合數可用階乘計算。','\\binom nr=\\frac{n!}{r!(n-r)!}','C(5,2)=10。','先確認 0≤r≤n。')],questions:[
M('基本係數','$(1+x)^5$ 中 $x^2$ 的係數是？',['5','10','15','20'],1,'由二項式定理，係數是 $\\binom52=10$。'),
M('包含負號的展開','$(1-2x)^4$ 中 $x^3$ 的係數是？',['32','−8','−32','16'],2,'$\\binom43(-2)^3=4(-8)=-32$。','應用'),
L('尋找指定項','展開 $(2+x)^4$，並求 $x^2$ 的係數。請展示二項式定理的應用。','$(2+x)^4=16+32x+24x^2+8x^3+x^4$。其中 $x^2$ 的係數為 $\\binom42 2^2=24$。建議評分：通項 1、各項展開 3、係數 1。') ]},
{title:'函數與三角學基礎',en:'Functions & Trigonometry',group:'基礎知識',unit:'官方單元 1、4（基礎）',glyph:'sin',desc:'認識奇偶函數、弧度與六種三角函數。',types:['奇偶函數','弧度與三角函數','函數圖像'],concepts:[
C('奇函數與偶函數','Odd and even functions','在對稱定義域上，偶函數關於 y 軸對稱，奇函數關於原點對稱。','f(-x)=f(x)\\quad\\text{or}\\quad f(-x)=-f(x)','x² 與 |x| 是偶函數；x³ 與 sin x 是奇函數。','並非每個函數都是奇函數或偶函數。'),
C('弧度','Radian measure','弧度等於弧長除以半徑，微積分中的三角函數公式採用弧度。','\\theta=\\frac{s}{r},\\qquad 180^\\circ=\\pi\\text{ rad}','60°=π/3 rad。','使用三角函數導數前檢查弧度制。'),
C('倒數三角函數','Reciprocal trigonometric functions','cosecant、secant、cotangent 分別為 sin、cos、tan 的倒數。','\\csc x=\\frac1{\\sin x},\\quad\\sec x=\\frac1{\\cos x},\\quad\\cot x=\\frac{\\cos x}{\\sin x}','sec(π/3)=2。','分母不可為零，須留意定義域。')],questions:[
M('辨認偶函數','下列哪一個是偶函數？',['$f(x)=x^3$','$f(x)=\\sin x$','$f(x)=x^2$','$f(x)=x+1$'],2,'$f(-x)=(-x)^2=x^2=f(x)$，因此 $x^2$ 是偶函數。'),
M('弧度換算','$150^\\circ$ 等於多少弧度？',['$\\frac{5\\pi}6$','$\\frac{3\\pi}4$','$\\frac{2\\pi}3$','$\\frac{5\\pi}3$'],0,'$150\\times\\pi/180=5\\pi/6$。','應用'),
L('函數的對稱性','判斷 $f(x)=x^4+2x^2$ 及 $g(x)=x^3+x$ 的奇偶性，並解釋其圖像的對稱性。','全體實數定義域對稱。$f(-x)=x^4+2x^2=f(x)$，故 f 為偶函數，圖像關於 y 軸對稱。$g(-x)=-x^3-x=-g(x)$，故 g 為奇函數，圖像關於原點對稱。建議評分：兩個代入與判斷各 2，圖像對稱性 1。') ]},
{title:'三角恆等式',en:'Trigonometric Identities',group:'基礎知識',unit:'官方單元 4（公式）',glyph:'cos',desc:'連結複角、二倍角、積化和差及和差化積。',types:['複角與二倍角','和差化積','恆等式證明'],concepts:[
C('複角公式','Compound angle formulae','sin、cos、tan 的和角與差角公式，是化簡與證明的基礎。','\\sin(A\\pm B)=\\sin A\\cos B\\pm\\cos A\\sin B','sin 75°=sin(45°+30°)=(√6+√2)/4。','cos(A+B) 中間是減號。'),
C('二倍角公式','Double angle formulae','同一公式可按題目需要，改寫成只含 sin 或 cos 的形式。','\\cos2x=1-2\\sin^2x=2\\cos^2x-1','sin²x=(1−cos 2x)/2，常用於積分。','tan 2x 的分母為 1−tan²x。'),
C('積化和差與和差化積','Product-to-sum and sum-to-product','利用複角公式相加或相減，可把積與和差互換。','2\\sin A\\cos B=\\sin(A+B)+\\sin(A-B)','sin 3x+sin x=2 sin 2x cos x。','cos A−cos B 的公式帶負號。')],questions:[
M('二倍角辨識','$1-2\\sin^2x$ 等於？',['$\\sin2x$','$\\cos2x$','$\\tan2x$','$2\\cos x$'],1,'由二倍角公式，$\\cos2x=1-2\\sin^2x$。'),
M('和差化積','$\\sin3x+\\sin x$ 等於？',['$2\\sin x\\cos x$','$2\\sin2x\\cos x$','$2\\cos2x\\sin x$','$\\sin4x$'],1,'使用 $\\sin A+\\sin B=2\\sin((A+B)/2)\\cos((A-B)/2)$。','應用'),
L('證明恆等式','在兩邊有定義的情況下，證明 $$\\frac{1-\\cos2x}{\\sin2x}=\\tan x.$$','由左方開始：$\\frac{2\\sin^2x}{2\\sin x\\cos x}=\\frac{\\sin x}{\\cos x}=\\tan x$。原式有定義要求 $\\sin2x\\ne0$，因此約去 sin x 合法。建議評分：二倍角代換 2、約分 1、結果 1、定義域說明 1。') ]},
{title:'極限與自然常數 e',en:'Limits & the Number e',group:'微積分',unit:'官方單元 5、6',glyph:'lim',desc:'理解變化的起點，建立微分與積分的基礎。',types:['代數極限','標準極限','極限計算'],concepts:[
C('極限的概念','Limit','極限研究自變數接近某值時，函數值的趨勢；不一定等於該點的函數值。','\\lim_{x\\to1}\\frac{x^2-1}{x-1}=2','先因式分解，再約去 x−1，可得極限 2。','0/0 是未定式，不能直接當成答案。'),
C('三角函數極限','Trigonometric limits','角度必須使用弧度。','\\lim_{x\\to0}\\frac{\\sin x}{x}=1','lim(x→0) sin(3x)/x=3。','分子與分母要配成同一變量。'),
C('自然常數與自然對數','The number e and natural logarithm','e 是指數與對數函數在微積分中使用的基本常數，ln 為以 e 為底的對數。','e=\\lim_{n\\to\\infty}\\left(1+\\frac1n\\right)^n','ln e=1；e^(ln x)=x，x>0。','ln x 在實數範圍要求 x>0。')],questions:[
M('可約去的因式','求 $\\displaystyle\\lim_{x\\to2}\\frac{x^2-4}{x-2}$。',['0','2','4','不存在'],2,'當 $x\\ne2$，分式等於 $x+2$，所以極限是 4。'),
M('標準三角極限','求 $\\displaystyle\\lim_{x\\to0}\\frac{\\sin5x}{x}$（弧度）。',['1','0','5','25'],2,'寫成 $5\\cdot\\frac{\\sin5x}{5x}$，極限為 $5$。','應用'),
L('有理化求極限','求 $$\\lim_{x\\to0}\\frac{\\sqrt{1+x}-1}{x}.$$ 展示有理化的步驟。','乘以共軛式後，原式在 $x\\ne0$ 時為 $1/(\\sqrt{1+x}+1)$。令 x 趨近 0，得到 $1/2$。建議評分：共軛式 1、正確有理化 2、約去 x 1、極限 1。') ]},
{title:'微分法',en:'Differentiation',group:'微積分',unit:'官方單元 7',glyph:'d/dx',desc:'從第一原理到連鎖律，掌握瞬間變化率。',types:['基本微分','連鎖律與乘積律','隱函數微分'],concepts:[
C('導數與第一原理','Derivative from first principles','導數是割線斜率在兩點無限接近時的極限。','f\'(x)=\\lim_{h\\to0}\\frac{f(x+h)-f(x)}h','若 f(x)=x²，差商為 2x+h，故 f′(x)=2x。','導數是局部變化率，並非函數值。'),
C('乘積律與商數律','Product and quotient rules','函數相乘或相除時，不能直接把導數相乘或相除。','(uv)\'=u\'v+uv\',\\quad(u/v)\'=\\frac{u\'v-uv\'}{v^2}','d(x sin x)/dx=sin x+x cos x。','商數律的分母是 v²。'),
C('連鎖律與隱函數微分','Chain rule and implicit differentiation','複合函數先微分外層，再乘內層導數。含 y 的項須乘 dy/dx。','\\frac{d}{dx}f(g(x))=f\'(g(x))g\'(x)','x²+y²=25 ⇒ 2x+2y y′=0。','d(y²)/dx=2y y′，不能漏掉 y′。')],questions:[
M('多項式微分','若 $f(x)=3x^4-2x+7$，則 $f\'(x)$ 是？',['$12x^3-2$','$12x^3+7$','$3x^3-2$','$12x^4-2$'],0,'冪次法則給出 $d(3x^4)/dx=12x^3$；常數導數是 0。'),
M('連鎖律','求 $\\frac{d}{dx}(2x+1)^3$。',['$3(2x+1)^2$','$6(2x+1)^2$','$6(2x+1)^3$','$2(2x+1)^2$'],1,'外層導數 $3(2x+1)^2$ 乘內層導數 2。','應用'),
L('圓的隱函數微分','曲線為 $x^2+y^2=25$。求 $dy/dx$，並求在 $(3,4)$ 的切線方程。','兩邊微分得 $2x+2y\\frac{dy}{dx}=0$，所以 $dy/dx=-x/y$（y≠0）。在 (3,4)，斜率 −3/4。切線 $y-4=-\\frac34(x-3)$，即 $3x+4y=25$。建議評分：微分 2、斜率 1、點斜式 1、方程 1。') ]},
{title:'微分的應用',en:'Applications of Differentiation',group:'微積分',unit:'官方單元 8',glyph:'f′',desc:'利用導數分析切線、極值與函數圖像。',types:['切線與法線','極值與單調性','最值問題'],concepts:[
C('切線與法線','Tangents and normals','切線斜率是該點的導數；非水平／垂直情況下，法線斜率是其負倒數。','y-y_0=f\'(x_0)(x-x_0)','若切線斜率為 2，法線斜率為 −1/2。','水平切線的法線是垂直線。'),
C('駐點與極值','Stationary points and extrema','f′=0 找出駐點，再以導數變號或二階導數判斷。','f\'(a)=0,\\quad f\'\'(a)>0\\Rightarrow\\text{local minimum}','f(x)=x² 的駐點 x=0 為局部最小值點。','f″=0 時不能直接判斷極值。'),
C('遞增、遞減與圖像','Monotonicity and curve sketching','在區間內由一階導數符號分析單調性，並結合截距、漸近線與凹凸性描繪圖像。','f\'(x)>0\\Rightarrow f\\text{ is increasing}','x³−3x 的導數是 3(x−1)(x+1)，在 (−1,1) 遞減。','閉區間求絕對最大／最小值時也要檢查端點。')],questions:[
M('切線斜率','$y=x^2$ 在 $x=3$ 的切線斜率為？',['3','6','9','12'],1,'$y\'=2x$，代入 x=3 得斜率 6。'),
M('二階導數判別','若 $f\'(2)=0$ 且 $f\'\'(2)>0$，則 $x=2$ 是？',['局部最大值點','局部最小值點','必定是拐點','不能判斷'],1,'二階導數在該駐點為正，表示局部最小值。','應用'),
L('固定周界的最大面積','一個長方形的周界為 20 cm。利用微分求其最大面積，並說明為何是最大值。','設長為 x cm，闊為 10−x，0<x<10。$A=x(10-x)$，$A\'=10-2x=0$ 得 x=5。$A\'\'=-2<0$，故最大面積為 $25\\text{ cm}^2$，長闊均為 5 cm。建議評分：建模 2、微分求解 1、判別 1、答案連單位 1。') ]},
{title:'不定積分',en:'Indefinite Integration',group:'微積分',unit:'官方單元 9（基本）',glyph:'∫',desc:'從導數反向思考，建立基本積分技巧。',types:['基本積分公式','三角與指數積分','初始條件'],concepts:[
C('反導函數','Antiderivative','不定積分表示一族導數相同的函數，答案包括任意常數。','\\int x^n\\,dx=\\frac{x^{n+1}}{n+1}+C\\quad(n\\ne-1)','∫3x² dx=x³+C。','一定要寫積分常數 C。'),
C('對數與指數積分','Logarithmic and exponential integrals','x⁻¹ 是冪次法則的例外。','\\int\\frac1x\\,dx=\\ln|x|+C,\\quad\\int e^x\\,dx=e^x+C','∫(1/x+eˣ) dx=ln|x|+eˣ+C。','ln|x| 中的絕對值不能隨意刪去。'),
C('三角函數與初始條件','Trigonometric integrals and initial conditions','利用已知導數反向積分，並代入已知點求常數。','\\int\\cos x\\,dx=\\sin x+C,\\quad\\int\\sin x\\,dx=-\\cos x+C','若 y′=2x 且 y(1)=3，則 y=x²+2。','積分後以微分驗算正負號。')],questions:[
M('冪次積分','$\\int4x^3\\,dx$ 是？',['$x^4+C$','$12x^2+C$','$4x^4+C$','$x^4$'],0,'冪次加 1，再除以新指數，並加上常數 C。'),
M('對數積分','$\\int\\frac{1}{x}\\,dx$（$x\\ne0$）是？',['$x^{-2}+C$','$\\ln|x|+C$','$\\ln x^2+C$','$1+C$'],1,'$d(\\ln|x|)/dx=1/x$，在不穿過 0 的區間成立。','應用'),
L('利用初始條件','已知 $dy/dx=6x^2-4x+1$ 及 $y(0)=2$，求 y。','積分得 $y=2x^3-2x^2+x+C$。代入 y(0)=2 得 C=2，故 $y=2x^3-2x^2+x+2$。建議評分：三項積分各 1、積分常數 1、初始條件與結果 1。') ]},
{title:'積分技巧',en:'Integration Techniques',group:'微積分',unit:'官方單元 9（技巧）',glyph:'∫u',desc:'按結構選擇代換法、分部積分與恆等式。',types:['代換積分','分部積分','技巧綜合'],concepts:[
C('代換積分','Integration by substitution','選擇內層函數作新變量，並同步轉換微分。','u=g(x),\\quad du=g\'(x)\\,dx','∫2x cos(x²) dx，令 u=x²，得 sin(x²)+C。','轉換後不要同時混用 x 與 u。'),
C('分部積分','Integration by parts','由乘積微分律反向推導，選擇微分後較簡單的項作 u。','\\int u\\,dv=uv-\\int v\\,du','∫x eˣ dx=x eˣ−eˣ+C。','M2 範圍中求一個積分最多使用兩次分部積分。'),
C('三角恆等式的應用','Using trigonometric identities','先化簡被積函數，再使用基本積分公式。','\\sin^2x=\\frac{1-\\cos2x}{2}','∫sin²x dx=x/2−sin(2x)/4+C。','雙角式積分時也須除以內層的係數。')],questions:[
M('辨認代換','$\\int2x\\cos(x^2)\\,dx$ 是？',['$\\cos(x^2)+C$','$\\sin(x^2)+C$','$2\\sin x+C$','$x^2\\sin x+C$'],1,'令 $u=x^2$，則 $du=2x\\,dx$，積分成 $\\int\\cos u\\,du$。'),
M('分部積分結果','$\\int xe^x\\,dx$ 是？',['$xe^x+C$','$(x+1)e^x+C$','$(x-1)e^x+C$','$x^2e^x/2+C$'],2,'取 u=x，dv=eˣ dx。結果為 $xe^x-\\int e^x dx=(x-1)e^x+C$。','應用'),
L('積分自然對數','利用分部積分求 $\\int\\ln x\\,dx$，其中 $x>0$，並以微分驗算。','取 $u=\\ln x$，$dv=dx$，所以 $du=dx/x$，$v=x$。積分為 $x\\ln x-\\int1\\,dx=x\\ln x-x+C$。微分得 $\\ln x+1-1=\\ln x$。建議評分：選取 1、微分積分 1、代入公式 1、答案 1、驗算 1。') ]},
{title:'定積分',en:'Definite Integration',group:'微積分',unit:'官方單元 10',glyph:'∫ᵇₐ',desc:'理解有向面積、上下限與積分的對稱性。',types:['基本定積分','對稱性與性質','定積分計算'],concepts:[
C('定積分與極限和','Definite integral as a limit of sums','定積分可理解為矩形面積的極限和，並由反導函數計算。','\\int_a^b f(x)\\,dx=F(b)-F(a),\\quad F\'=f','∫₀² x dx=[x²/2]₀²=2。','先代上限，再減下限；不加 C。'),
C('區間與方向','Intervals and orientation','顛倒積分上下限會改變符號，也可把區間分拆。','\\int_b^a f(x)\\,dx=-\\int_a^b f(x)\\,dx','∫₁⁰ x dx=−1/2。','定積分可為負數，面積則不會。'),
C('奇偶函數與對稱區間','Symmetry of definite integrals','奇函數在對稱區間的積分為零；偶函數可計算半邊後乘 2。','\\int_{-a}^{a}f_{\\text{odd}}(x)\\,dx=0','∫₋₁¹ x³ dx=0；∫₋₁¹ x² dx=2/3。','必須先確定奇偶性及對稱區間。')],questions:[
M('代入上下限','計算 $\\int_0^2x\\,dx$。',['1','2','4','0'],1,'$[x^2/2]_0^2=2$。'),
M('奇函數積分','計算 $\\int_{-2}^{2}x^3\\,dx$。',['0','4','8','16'],0,'x³ 為奇函數，對稱區間上的定積分為 0。','應用'),
L('定積分與代換','計算 $$\\int_0^1 2x(x^2+1)^2\\,dx$$，並展示新積分上下限。','令 $u=x^2+1$，$du=2x\\,dx$。當 x=0，u=1；當 x=1，u=2。所以積分 $=\\int_1^2u^2du=[u^3/3]_1^2=7/3$。建議評分：代換 1、微分 1、新上下限 1、積分 1、答案 1。') ]},
{title:'定積分的應用',en:'Applications of Integration',group:'微積分',unit:'官方單元 11',glyph:'π∫',desc:'把積分轉化為平面面積與旋轉體體積。',types:['曲線下的面積','旋轉體體積','曲線之間的面積'],concepts:[
C('面積與符號','Area and signed integral','幾何面積是非負量；曲線穿過 x 軸時需要分段。','A=\\int_a^b|f(x)|\\,dx','y=x 在 [−1,1] 的定積分為 0，但面積為 1。','不要把負的積分直接稱為負面積。'),
C('兩曲線之間','Area between curves','先找交點與上下關係，再積分上方函數減下方函數。','A=\\int_a^b(f(x)-g(x))\\,dx\\quad(f\\ge g)','在 [0,1]，x 在 x² 上方，面積為 1/6。','交點之外可能需要調換上下函數。'),
C('旋轉體體積','Volumes of revolution','繞 x 軸旋轉，以截面的圓面積積分；繞平行直線旋轉須使用到該軸的距離。','V=\\pi\\int_a^b [f(x)]^2\\,dx','y=x 在 0≤x≤1 下的區域繞 x 軸旋轉，V=π/3。','旋轉半徑要平方，並寫體積單位。')],questions:[
M('曲線下面積','$y=x^2$、x 軸、$x=0$ 及 $x=1$ 圍成的面積為？',['$1/2$','$1/3$','1','2'],1,'面積為 $\\int_0^1x^2dx=[x^3/3]_0^1=1/3$。'),
M('繞 x 軸旋轉','由 $y=x$、x 軸、$x=0$、$x=1$ 圍成的區域繞 x 軸旋轉，體積為？',['$\\pi$','$\\pi/2$','$\\pi/3$','$2\\pi/3$'],2,'$V=\\pi\\int_0^1x^2dx=\\pi/3$。','應用'),
L('兩條曲線之間','求曲線 $y=x$ 與 $y=x^2$ 圍成的有限區域面積。請找出交點並列出積分式。','交點由 $x=x^2$ 得 x=0,1。在 [0,1]，x≥x²。所以 $A=\\int_0^1(x-x^2)dx=[x^2/2-x^3/3]_0^1=1/6$。建議評分：交點 1、上下關係 1、積分式 1、積分 1、答案 1。') ]},
{title:'矩陣與行列式',en:'Matrices & Determinants',group:'代數與向量',unit:'官方單元 12、13',glyph:'[A]',desc:'學習矩陣運算、行列式與逆矩陣。',types:['矩陣與行列式基礎','逆矩陣','矩陣運算'],concepts:[
C('矩陣乘法','Matrix multiplication','m×n 矩陣只能右乘 n×p 矩陣，結果為 m×p；一般不可交換次序。','(AB)_{ij}=\\sum_k a_{ik}b_{kj}','[1 2] 乘 [3;4] 得 11。','AB 與 BA 不一定相等，甚至可能只有一個有定義。'),
C('二階與三階行列式','Determinants of order 2 and 3','二階行列式是 ad−bc；三階可按一行或一列作餘因子展開。','\\det\\begin{pmatrix}a&b\\\\c&d\\end{pmatrix}=ad-bc','det[[1,2],[3,4]]=−2。','行列式為數值，矩陣則是一組元素的排列。'),
C('逆矩陣','Inverse matrices','方陣行列式非零時存在逆矩陣；二階用公式，三階可用伴隨矩陣法。','A^{-1}=\\frac1{ad-bc}\\begin{pmatrix}d&-b\\\\-c&a\\end{pmatrix}','對角矩陣 diag(2,3) 的逆是 diag(1/2,1/3)。','行列式等於零時不能使用逆矩陣公式。')],questions:[
M('二階行列式','求 $\\det\\begin{pmatrix}2&1\\\\3&4\\end{pmatrix}$。',['11','5','−5','8'],1,'$2\\times4-1\\times3=5$。'),
M('可逆條件','一個方陣 A 有逆矩陣的充要條件是？',['$\\det A=0$','$\\det A=1$','$\\det A\\ne0$','A 所有元素非零'],2,'方陣可逆當且僅當行列式不為 0。','應用'),
L('求二階逆矩陣','設 $A=\\begin{pmatrix}1&2\\\\3&7\\end{pmatrix}$。求 $A^{-1}$，並以矩陣乘法驗算。','det A=7−6=1，故 $A^{-1}=\\begin{pmatrix}7&-2\\\\-3&1\\end{pmatrix}$。$AA^{-1}=\\begin{pmatrix}7-6&-2+2\\\\21-21&-6+7\\end{pmatrix}=I$。建議評分：行列式 1、逆矩陣 2、驗算 2。') ]},
{title:'線性方程組',en:'Systems of Linear Equations',group:'代數與向量',unit:'官方單元 14',glyph:'Ax=b',desc:'利用克拉默法則、逆矩陣與消元法解方程。',types:['解的性質','矩陣解法','高斯消元法'],concepts:[
C('矩陣形式','Matrix form','把係數、未知數及常數分別寫成矩陣，方便分析方程組。','A\\mathbf{x}=\\mathbf{b}','2x+y=5、x−y=1 的係數矩陣是 [[2,1],[1,−1]]。','未知數的排列次序必須一致。'),
C('克拉默法則與逆矩陣','Cramer’s rule and inverse matrices','係數行列式非零時，方程組有唯一解。','x_i=\\frac{\\det A_i}{\\det A},\\qquad\\mathbf{x}=A^{-1}\\mathbf b','A_i 由 A 的第 i 列（column）替換為常數向量得到。','行列式等於零不能直接斷定無解。'),
C('高斯消元法','Gaussian elimination','對增廣矩陣作初等行運算，化成階梯形後回代。','[A\\mid\\mathbf b]\\longrightarrow\\text{row echelon form}','出現 [0 0 0 | 1] 代表矛盾，因此無解。','0=0 不是矛盾；還要檢查自由變量。')],questions:[
M('唯一解條件','若係數矩陣 A 的行列式不為零，$A\\mathbf x=\\mathbf b$ 有甚麼解？',['無解','唯一解','無限多解','不能判斷'],1,'A 可逆，所以 $\\mathbf x=A^{-1}\\mathbf b$ 是唯一解。'),
M('判斷相依方程','方程 $x+y=2$ 及 $2x+2y=4$ 有？',['無解','唯一解 $(1,1)$','無限多解','兩個解'],2,'第二條方程是第一條的 2 倍，兩者代表同一直線。','應用'),
L('解二元方程組','用消元法或矩陣方法解 $$2x+y=5,\\qquad x-y=1.$$','兩式相加得 3x=6，故 x=2。代回 x−y=1 得 y=1。驗算 2(2)+1=5 及 2−1=1。建議評分：方法與消元 2、x 1、y 1、驗算 1。') ]},
{title:'向量基礎',en:'Introduction to Vectors',group:'代數與向量',unit:'官方單元 15',glyph:'v⃗',desc:'以方向與大小描述平面及空間的幾何關係。',types:['向量運算','單位向量與分點','向量幾何'],concepts:[
C('向量與位置向量','Vectors and position vectors','向量同時有大小與方向；由 A 指向 B 的向量是位置向量之差。','\\overrightarrow{AB}=\\mathbf b-\\mathbf a','A=(1,2)，B=(4,6)，則 AB=(3,4)。','AB 與 BA 的方向相反。'),
C('大小與單位向量','Magnitude and unit vectors','非零向量除以其大小，可得到同方向的單位向量。','|\\mathbf v|=\\sqrt{x^2+y^2+z^2},\\qquad\\hat{\\mathbf v}=\\frac{\\mathbf v}{|\\mathbf v|}','v=(3,4,0)，|v|=5，單位向量=(3/5,4/5,0)。','零向量沒有指定方向的單位向量。'),
C('分點與平行','Division of a line segment and parallelism','內分點的位置向量可由端點加權平均求得；平行非零向量互為倍數。','AP:PB=m:n\\Rightarrow\\mathbf p=\\frac{n\\mathbf a+m\\mathbf b}{m+n}','中點的位置向量為 (a+b)/2。','內分公式中，a 的係數是對邊比 n。')],questions:[
M('向量大小','向量 $\\mathbf v=(3,4,0)$ 的大小為？',['7','1','5','25'],2,'$|\\mathbf v|=\\sqrt{3^2+4^2+0^2}=5$。'),
M('兩點之間的向量','若 $A=(1,2,3)$，$B=(3,1,5)$，則 $\\overrightarrow{AB}$ 是？',['$(2,-1,2)$','$(-2,1,-2)$','$(4,3,8)$','$(2,1,2)$'],0,'$\\overrightarrow{AB}=B-A=(3-1,1-2,5-3)=(2,-1,2)$。','應用'),
L('中點與長度','已知 $A=(1,2,0)$、$B=(5,6,0)$。求 AB 的中點 M、向量 AB 及長度 |AB|。','中點 $M=((1+5)/2,(2+6)/2,0)=(3,4,0)$。$\\overrightarrow{AB}=(4,4,0)$，大小為 $\\sqrt{16+16}=4\\sqrt2$。建議評分：中點 2、向量 1、長度 2。') ]},
{title:'向量積與幾何應用',en:'Vector Products & Geometry',group:'代數與向量',unit:'官方單元 16、17',glyph:'a×b',desc:'運用數量積與向量積，處理角度、投影及面積。',types:['數量積與夾角','向量積','空間幾何應用'],concepts:[
C('數量積','Scalar product / dot product','數量積的結果是數值，可用於求夾角、判斷垂直與投影。','\\mathbf a\\cdot\\mathbf b=|\\mathbf a||\\mathbf b|\\cos\\theta','(1,0,0)·(0,1,0)=0，兩個非零向量垂直。','求夾角公式中，兩個向量都必須非零。'),
C('向量積','Vector product / cross product','三維向量積垂直於兩個原向量，方向遵循右手定則。','|\\mathbf a\\times\\mathbf b|=|\\mathbf a||\\mathbf b|\\sin\\theta','i×j=k，而 j×i=−k。','交換次序會改變符號。'),
C('投影、面積與距離','Projection, areas and distances','向量積的大小給出平行四邊形面積，半數為三角形面積；投影可用於最短距離。','A_{\\triangle}=\\frac12|\\overrightarrow{AB}\\times\\overrightarrow{AC}|','兩條互相垂直且長為 3、4 的邊，三角形面積為 6。','先確定兩個邊向量由同一頂點出發。')],questions:[
M('數量積','求 $(1,2,0)\\cdot(3,-1,0)$。',['5','1','−1','0'],1,'逐項相乘再相加：$1(3)+2(-1)+0=1$。'),
M('向量積與面積','若 $|\\mathbf a\\times\\mathbf b|=12$，由 a、b 作相鄰邊的三角形面積為？',['24','12','6','3'],2,'三角形面積是平行四邊形面積的一半，為 6。','應用'),
L('空間三角形的面積','設 $A=(0,0,0)$、$B=(2,0,0)$、$C=(0,3,0)$。用向量積求三角形 ABC 的面積。','AB=(2,0,0)，AC=(0,3,0)。$\\overrightarrow{AB}\\times\\overrightarrow{AC}=(0,0,6)$，大小為 6，故面積為 $6/2=3$。建議評分：兩個邊向量 1、向量積 2、大小 1、面積 1。') ]}
];
COURSE.forEach((c,i)=>{c.id=i+1;c.questions.forEach((q,j)=>{q.id=`${i+1}-${j+1}`;q.chapter=i+1;q.section=j;q.type=c.types[j]});});
