// Shared rubric policy. Historical five-star data is retained for audit only.
const DIFFICULTY_LABELS={1:'基礎 Foundation',2:'進階 Intermediate',3:'挑戰 Challenge'};
const ROLE_LABELS={example:'例題示範',variation:'變式訓練',trap:'陷阱專練',capstone:'綜合壓軸'};
function rubricLevel(scores){const values=Object.values(scores);if(values.length!==4||!values.every(v=>Number.isInteger(v)&&v>=1&&v<=3))throw new Error('Invalid A–D scores');const n=values.reduce((a,b)=>a+b,0);return n>=10?3:n>=7||values.includes(3)?2:1;}
function rubricStatus(r){return r.status==='worked-reviewed'?'已對照解答':r.status==='strategy-reviewed'?'按策略重評 · 待解答核對':'文字初評 · 待核對';}
for(const c of CHAPTERS)for(const q of c.questions){
 const r=DIFFICULTY_RUBRICS.questions[q.id];if(!r)throw new Error('Missing rubric '+q.id);
 q.legacyDifficulty={level:q.difficultyLevel,label:q.difficulty,reason:q.difficultyReason,status:q.difficultyStatus};
 q.rubric=r;q.difficultyLevel=rubricLevel(r.scores);q.difficulty=`L${q.difficultyLevel} · ${DIFFICULTY_LABELS[q.difficultyLevel]}`;
 q.difficultyReason=Object.entries(r.reasons).map(([k,v])=>`${k}: ${v}`).join(' ');q.difficultyStatus=r.status;
 if(q.tags)q.tags=q.tags.map(t=>t==='逐題評定'?'逐題策略整理':t);
 q.roles=r.roles;q.estimatedMinutes=r.estimatedMinutes;
 if(q.subparts?.length)q.subparts=q.subparts.map(p=>{const part=r.subparts?.find(s=>s.part===p.part);return {...p,legacyDifficultyLevel:p.difficultyLevel,difficultyLevel:part?rubricLevel(part.scores):null,rubric:part||null};});
}
