"""Package current Site changes for the existing GitHub Pages archive workflow."""
from pathlib import Path
import subprocess,sys,zipfile
root=Path(__file__).resolve().parents[1]
output=Path(sys.argv[1]);output.parent.mkdir(parents=True,exist_ok=True)
changed=subprocess.check_output(['git','diff','--name-only','--diff-filter=ACM'],cwd=root,text=True).splitlines()
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines()
files=sorted(set(changed+new))
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
 for name in files:
  p=root/name
  if not p.is_file() or not name.startswith(('docs/','content/','scripts/')):continue
  target='docs/'+name[5:] if name.startswith('docs/') else name
  if p.suffix in ['.py','.cjs']:
   text=p.read_text().replace('docs/','docs/').replace("'docs'","'docs'").replace('"docs"','"docs"')
   z.writestr(target,text)
  else:z.write(p,target)
print(output,output.stat().st_size,'bytes')
