"""Merge explicitly reviewed Ppp records; never infer difficulty from keywords."""
import json,re,hashlib,math
from pathlib import Path
import fitz
from PIL import Image
R=Path(__file__).resolve().parents[1]
review=json.loads((R/'content/ppp-reviewed.json').read_text())
root=Path(__file__).resolve().parents[3]
inputs=Path(__import__('sys').argv[1])
bank=json.loads((R/'content/imported-bank.json').read_text())
previous_ids=[q['id'] for q in bank['questions']]
existing={}
for q in bank['questions']:
 m=re.fullmatch(r'(20\d\d)-DSE-MATH-EP\(M2\) #(\d+)',q.get('paperReference',''))
 if m:existing[(int(m[1]),int(m[2]))]=q
files={int(re.search(r'20\d\d',f.name)[0]):f for f in inputs.glob('*.pdf')}
rendered=set();added=[];enriched=[];rows=[]
for r in review:
 year,num=r['year'],r['number'];key=(year,num);sid=f'ppp-{year}';srcfile=files[year];doc=fitz.open(srcfile)
 assert 1<=r['difficultyLevel']<=5 and r['difficultyReason'] and r['approach']
 if key in existing:
  q=existing[key]
  if 'legacySource' not in q:
   q['legacySource']={k:q.get(k) for k in ['sourceId','sourceTitle','sourceQuestion','sourcePage','assets','sourceOccurrences','solutionNote','title','type','chapter','difficulty','difficultyLevel','difficultyReason']}
  q['linkedSourceIds']=list(set(q.get('linkedSourceIds',[])+[q['legacySource']['sourceId']]))
  enriched.append(q['id'])
 else:
  q={'id':f'src-ppp-{year}-q{num:02}','kind':'long','extension':False};bank['questions'].append(q);added.append(q['id'])
 assets=[]
 for a in r['assets']:
  page=doc[a['page']-1];rot=a.get('rotation',0);w,h=(page.rect.height,page.rect.width) if rot in [90,270] else (page.rect.width,page.rect.height)
  top,bottom=max(0,a['top']),min(h,a['bottom']);assert bottom>top,(year,num,a)
  img=f'source-pages/ppp-{year}-p{a["page"]:02}'+(f'-r{rot}' if rot else '')+'.webp'
  if img not in rendered:
   # Scale to a consistent ~1250px readable page, including high-resolution PDFs.
   scale=1250/w;pix=page.get_pixmap(matrix=fitz.Matrix(scale,scale),alpha=False)
   image=Image.frombytes('RGB',[pix.width,pix.height],pix.samples)
   if rot:image=image.rotate(-rot,expand=True)
   image.save(R/'docs'/img,'WEBP',quality=85,method=4);rendered.add(img)
  asset={'src':img,'page':a['page'],'width':w,'height':h,'top':round(top,2),'bottom':round(bottom,2)}
  if a.get('left') is not None:asset.update(left=max(0,a['left']),right=min(w,a.get('right',w)))
  assets.append(asset)
 q.update(chapter=r['chapter'],type=r['type'],title=f'{year} HKDSE M2 · Q{num:02} · {r["type"]}',prompt=f'請作答下方 {year} HKDSE M2 第 {num} 題。保留原題圖像及全部小題；可按「完整原頁」核對。',sourceId=sid,sourceTitle=f'Ppp · HKDSE {year} M2',sourceKind='ppp',sourceQuestion=f'{year} #'+str(num).zfill(2),sourcePage=assets[0]['page'],assets=assets,pppYear=year,pppNumber=num,relatedChapters=r.get('relatedChapters',[]),topics=r['topics'],functionFamilies=r.get('functionFamilies',['unclassified']),methodTags=r.get('methodTags',[]),difficultyLevel=r['difficultyLevel'],difficulty='Lv'+str(r['difficultyLevel'])+' '+'★'*r['difficultyLevel'],difficultyReason=r['difficultyReason'],difficultyStatus='reviewed',reviewApproach=r['approach'],subparts=r.get('subparts',[]),marks=r.get('marks'),paperReference=f'{year}-DSE-MATH-EP(M2) #{num:02}',tags=[str(year),'Ppp 原卷','逐題評定'],searchText=' '.join([str(year),str(num),r['type'],*r['topics'],r['approach']]))
 if r.get('sourceNote'):q['sourceNote']=r['sourceNote']
 if q.get('legacySource'):
  legacy=q['legacySource'];occ=legacy.get('sourceOccurrences') or [{'page':legacy['sourcePage'],'assets':legacy['assets']}]
  q['sourceOccurrences']=[{'page':assets[0]['page'],'assets':assets,'sourceTitle':q['sourceTitle']}]+[{**o,'sourceTitle':legacy['sourceTitle']} for o in occ]
  if q.get('solutionAssets'):q['solutionNote']='以下答案來自先前 bk1 題集的同年份、同題號節錄／改編版本，可能只對應部分小題，並不保證涵蓋此完整原卷題目；不是本站核實的完整官方評分準則。'
 rows.append({'year':year,'number':num,'id':q['id'],'merged':key in existing,'chapter':q['chapter'],'topics':q['topics'],'level':q['difficultyLevel'],'assets':assets})
for year,f in sorted(files.items()):
 sid=f'ppp-{year}'
 if not any(s['id']==sid for s in bank['sources']):bank['sources'].append({'id':sid,'title':f'Ppp · HKDSE {year} M2','filename':f.name,'pages':len(fitz.open(f)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'kind':'ppp','count':0})
for s in bank['sources']:s['count']=sum(q['sourceId']==s['id'] or s['id'] in q.get('linkedSourceIds',[]) for q in bank['questions'])
(R/'content/imported-bank.json').write_text(json.dumps(bank,ensure_ascii=False,separators=(',',':')))
report={'files':15,'reviewedQuestions':len(review),'added':len(added),'enriched':len(enriched),'originalTotal':2473,'totalQuestions':len(bank['questions'])+45,'preservedIds':enriched,'previousImportedIds':previous_ids,'newIds':added,'sourcePagesRendered':len(rendered),'byYear':{str(y):sum(r['year']==y for r in review) for y in files},'questions':rows,'ratingMethod':'Per-question editorial estimates using original page review and explicit solution approach; not official ratings or empirically calibrated. No keyword-based difficulty inference.'}
(R/'content/ppp-import-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print({k:v for k,v in report.items() if k not in ['questions','preservedIds','newIds','previousImportedIds']})
