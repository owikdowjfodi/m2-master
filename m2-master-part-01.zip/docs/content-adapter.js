/* Stable original IDs keep existing practice histories intact. */
const PREP={id:0,title:'根式與分母有理化',en:'Surds & Rationalisation',group:'先備知識',unit:'銜接課題',glyph:'√x',desc:'先鞏固根式運算、定義域與共軛式，為 M2 代數運算打好基礎。',types:[],concepts:[],questions:[]};
const CHAPTERS=[PREP,...COURSE];
for(const q of IMPORTED_BANK.questions){const c=CHAPTERS.find(c=>c.id===q.chapter);if(!c)throw new Error('Unknown chapter '+q.chapter);if(!c.types.includes(q.type))c.types.push(q.type);q.section=c.types.indexOf(q.type);c.questions.push(q);}
const CONTENT_STATS={imported:IMPORTED_BANK.questions.length,notes:Object.values(LESSONS).reduce((s,p)=>s+p.length,0),sources:IMPORTED_BANK.sources.length};
