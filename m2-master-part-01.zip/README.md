# M2 Master

An account-free HKDSE Mathematics Extended Part Module 2 practice website.

- 15 teaching chapters and a supplementary prerequisite area.
- 77 English Concepts & Formulas pages with LaTeX, derivations, worked examples and self-checks.
- 2,473 questions: 2,428 imported source questions and 45 original exercises.
- Multiple-choice marking, original question images, printed answer excerpts and handwritten answer drafts.
- Responsive layouts and light/dark mode. KaTeX and its fonts are bundled locally.

## GitHub Pages

Publish the `main` branch, `/docs` folder from **Settings → Pages → Deploy from a branch**. No API keys, ChatGPT account, OpenAI connection, paid AI API or build service is required by the website.

## Editing and checking

`content/lessons.md` is the editable English note source. `content/imported-bank.json` is the question bank; source provenance is recorded in the adjacent manifests. After changing content, run:

```sh
python3 scripts/build-content.py
node scripts/validate-content.cjs
```

Commit the regenerated `docs` files. GitHub Pages republishes the `docs` folder after updates to `main`.

## Privacy and hosting changes

MC attempts and bookmarks use browser localStorage. Handwritten drafts and pictures use IndexedDB, with no server uploads or cloud marking. Data is specific to the website origin and browser; records on a previous hosting domain will not automatically appear on the GitHub Pages domain. Preserve original answer photos and export MC records before moving devices.

## Content attribution

The 15 chapters are teaching units, not an official HKEAA chapter list. Source papers and their images remain the property of their respective authors, publishers and examination bodies. The bk1 compilation retains dse.life attribution; extensions and legacy examination provenance are labelled. Printed answer excerpts are not represented as complete official marking schemes. No licence to third-party paper content is granted by this repository.
